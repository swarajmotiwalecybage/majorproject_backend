package com.cybage.uhs;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication 
public class UniversalHealthServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniversalHealthServicesApplication.class, args);
	}

}
