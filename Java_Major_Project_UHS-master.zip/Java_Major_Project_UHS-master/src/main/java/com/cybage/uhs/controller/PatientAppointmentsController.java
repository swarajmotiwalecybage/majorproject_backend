package com.cybage.uhs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.uhs.bean.APIResponseEntity;
import com.cybage.uhs.model.PatientsAppointments;
import com.cybage.uhs.service.PatientAppointmentsService;

@RestController
@RequestMapping("/appointments")
@CrossOrigin
public class PatientAppointmentsController {

	@Autowired
	PatientAppointmentsService patientAppointmentsService;

	@GetMapping("/get-all")
	public ResponseEntity<APIResponseEntity> getAllAppointments() {
		APIResponseEntity allAppointments = patientAppointmentsService.getAllPaitientsAppointments();
		return new ResponseEntity<APIResponseEntity>(allAppointments, HttpStatus.OK);
	}

	@GetMapping("/get-by-id/{appointmentId}")
	public ResponseEntity<APIResponseEntity> getAppointmentById(@PathVariable Long appointmentId) {
		APIResponseEntity appointment = patientAppointmentsService.getAppointmentById(appointmentId);
		return new ResponseEntity<APIResponseEntity>(appointment, HttpStatus.OK);
	}
	@GetMapping("/admin/get-all")
	public ResponseEntity<APIResponseEntity> getAllAppointmentsForAdmin() {
		APIResponseEntity allAppointments = patientAppointmentsService.getAllAppointmentsForAdmin();
		return new ResponseEntity<APIResponseEntity>(allAppointments, HttpStatus.OK);
	}

	@GetMapping("/doctor/get-all/{doctorId}")
	public ResponseEntity<APIResponseEntity> getAllAppointmentsForDoctor(@PathVariable Long doctorId) {
		APIResponseEntity allAppointments = patientAppointmentsService
				.getAllAppointmentsForDoctor(doctorId);
		return new ResponseEntity<APIResponseEntity>(allAppointments, HttpStatus.OK);
	}

	@GetMapping("/patient/get-all/{patientId}")
	public ResponseEntity<APIResponseEntity> getAllAppointmentsForPatient(
			@PathVariable Long patientId) {
		APIResponseEntity allAppointments = patientAppointmentsService
				.getAllAppointmentsForPatient(patientId);
		return new ResponseEntity<APIResponseEntity>(allAppointments, HttpStatus.OK);
	}

	@PostMapping("/add-appointment")
	public ResponseEntity<APIResponseEntity> addAppointment(@RequestBody PatientsAppointments patientsAppointments) {
		APIResponseEntity appointmentReponse = patientAppointmentsService.addAppointment(patientsAppointments);
		return new ResponseEntity<APIResponseEntity>(appointmentReponse, HttpStatus.OK);
	}

	@PutMapping("/update-appointment/{appointmentId}")
	public ResponseEntity<APIResponseEntity> updateAppointment(@RequestBody PatientsAppointments patientsAppointments,@PathVariable Long appointmentId) {
		APIResponseEntity updateAppointmentReponse = patientAppointmentsService.updateAppointment(patientsAppointments,				appointmentId);
		return new ResponseEntity<APIResponseEntity>(updateAppointmentReponse, HttpStatus.OK);
	}

	@PutMapping("/add-prescription/{appointmentId}")
	public ResponseEntity<APIResponseEntity> addAppointmentsPrescription(@RequestBody PatientsAppointments patientsAppointments,
			@PathVariable Long appointmentId) {
		APIResponseEntity addAppointmentsPrescriptionReponse = patientAppointmentsService
				.addAppointmentsPrescription(patientsAppointments, appointmentId);
		return new ResponseEntity<APIResponseEntity>(addAppointmentsPrescriptionReponse, HttpStatus.OK);
	}

	@GetMapping("/change-status/{appointmentId}/{status}")
	public ResponseEntity<APIResponseEntity> changeAppointmentStatus(@PathVariable Long appointmentId,
			@PathVariable String status) {
				APIResponseEntity appointmentStatusResponse = patientAppointmentsService.changeAppointmentStatus(appointmentId, status);
		return new ResponseEntity<APIResponseEntity>(appointmentStatusResponse, HttpStatus.OK);
	}

}
