package com.cybage.uhs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.uhs.bean.APIResponseEntity;
import com.cybage.uhs.model.FilesModel;
import com.cybage.uhs.service.FilesService;
import com.cybage.uhs.service.UsersService;

@RestController
@RequestMapping("/patients")
@CrossOrigin
public class PatientsController {

	@Autowired
	UsersService usersService;
	@Autowired
	FilesService filesService;

	@GetMapping("/get-all-patients")
	public ResponseEntity<APIResponseEntity> getAllUsersAccordingToRole() {
		APIResponseEntity response = usersService.getAllUsersAccordingToRole(3);
		return new ResponseEntity<APIResponseEntity>(response, HttpStatus.OK);
	}

}
