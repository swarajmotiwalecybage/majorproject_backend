package com.cybage.uhs.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExcetion {
	@ExceptionHandler(RecordException.class)
	public ResponseEntity<String> handleRecordNotFound(RecordException exception) {
		return new ResponseEntity<String>(exception.getMessage(), HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(InvalidInput.class)
	public ResponseEntity<String> handleInvalidInput(InvalidInput exception) {
		return new ResponseEntity<String>(exception.getMessage(), HttpStatus.NOT_FOUND);
	}

}
