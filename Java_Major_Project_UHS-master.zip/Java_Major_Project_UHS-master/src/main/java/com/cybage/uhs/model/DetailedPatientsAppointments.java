package com.cybage.uhs.model;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class DetailedPatientsAppointments {

	@Id
	@GeneratedValue
	@Column
	private int appointmentId;
	private Long patientId;
	private String patientsFirstname;
	private String patientsLastname;
	private String email;
	private Long doctorId;
	private String doctorsFirstname;
	private String doctorsLastname;
	private String doctorsEmail;
	private Date appointmentDate;
	private Time appointmentTime;
	private String appointmentStatus;
	private String feedback;
	private Integer doctorsRatings;
	private String patientsNotes;
	private String prescription;
	private Timestamp createdTime;

}
