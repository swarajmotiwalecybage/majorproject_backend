package com.cybage.uhs.model;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class DetailedPatientsComplaints {

	@Id
	@GeneratedValue
	@Column
	private Long patientComplaintsId;
	private Long patientId;
	private String patientsFirstname;
	private String patientsLastname;
	private String email;
	private String complaintStatus;
	private String complaintType;
	private String complaintDescription;
	private String adminReply;
	private Timestamp createdTime;
	private Timestamp reminderSentTime;
	private int reminderSent;
	

}
