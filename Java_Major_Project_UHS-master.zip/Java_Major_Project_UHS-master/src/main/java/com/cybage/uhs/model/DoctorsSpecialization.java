package com.cybage.uhs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class DoctorsSpecialization {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "doctorsSpecializationId")
	private int doctorsSpecializationId;

	@Column
	private Long doctorId;
	@Column
	private int specializationId;
	public DoctorsSpecialization(Long doctorId, int specializationId) {
		super();
		this.doctorId = doctorId;
		this.specializationId = specializationId;
	}

//	@ManyToOne
//	@JoinColumn(name = "doctorDetail")
//	private Users users;
//
//	@ManyToOne
//	@JoinColumn(name = "specializationId")
//	private Specialization specialization;
//
//	public DoctorsSpecialization(Users users, Specialization specialization) {
//		super();
//		this.users = users;
//		this.specialization = specialization;
//	}

}
