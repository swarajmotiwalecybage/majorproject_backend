package com.cybage.uhs.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
public class PatientComplaints {

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "patientComplaintsId")
	private Long patientComplaintsId;

	@Column(name = "patientId")
	private Long patientId;

	@Column(name = "complaintStatus")
	private String complaintStatus;

	@Column(name = "complaintType")
	private String complaintType;

	@Column(name = "complaintDescription")
	private String complaintDescription;

	@Column(name = "adminReply")
	private String adminReply;

	@Column(name = "createdTime")
	private Timestamp createdTime;
	
	@Column(name = "reminderSentTime")
	private Timestamp reminderSentTime;
	
	@Column(name = "reminderSent")
	private int reminderSent;

}
