package com.cybage.uhs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class Specialization {
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "specializationId")
	private int specializationId;
	
	
	@Column	
	private String category;
	
//	@OneToMany(mappedBy="specialization")
//	@JsonIgnore
//	private List<DoctorsSpecialization> doctorsSpecialization;


}
