package com.cybage.uhs.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class Users {
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO) 
	@Column(name = "usersId")
	private Long usersId;

	@Column(name = "usersRoleId")
	private int usersRoleId;
	

	@Column(name = "firstname")
	private String firstname;

	@Column(name = "lastname")
	private String lastname;

	@Column(name = "email")
	private String email;
	

	@Column(name = "accountStatus")
	private int accountStatus;
	

	@Column(name = "usersProfileUrl")
	private String usersProfileUrl;

	@Column(name = "mobile")
	private String mobile;

	@Column(name = "loginAttempts")
	private Integer loginAttempts;

	@Column(name = "accountCreated")
	private Timestamp accountCreated;

	@Column(name = "usersOTP")
	private Integer usersOTP;

//	@OneToMany(mappedBy = "users")
//	@JsonIgnore
//	private List<DoctorsSpecialization> doctorsSpecialization;
	
//	@OneToMany(mappedBy = "users")
//	@JsonIgnore
//	private List<PatientsAppointments> appointments;
	

	public Users(String firstname, String lastname, String email, String usersProfileUrl,
			String mobile) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.usersProfileUrl = usersProfileUrl;
		this.mobile = mobile;
	}

}
