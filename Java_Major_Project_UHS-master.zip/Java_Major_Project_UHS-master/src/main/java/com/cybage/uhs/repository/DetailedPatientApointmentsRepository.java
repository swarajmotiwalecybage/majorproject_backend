package com.cybage.uhs.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cybage.uhs.model.DetailedPatientsAppointments;

@Repository
public interface DetailedPatientApointmentsRepository extends JpaRepository<DetailedPatientsAppointments, Integer> {


	@Query(value = "select  appointment_id, patient_id, firstname as patients_firstname, "
			+ "lastname as patients_lastname, email, doctor_id,"
			+ "(select firstname from users where users.users_id = patients_appointments.doctor_id) as doctors_firstname, "
			+ "(select lastname from users where users.users_id = patients_appointments.doctor_id) as doctors_lastname, "
			+ "(select email from users where users.users_id = patients_appointments.doctor_id) as doctors_email, "
			+ "appointment_date, appointment_time,appointment_status,"
			+ "feedback , doctors_ratings, patients_notes, prescription, created_time from users inner join patients_appointments "
			+ "on patients_appointments.patient_id = users.users_id where patients_appointments.appointment_id = ?1 "
			, nativeQuery = true)
	DetailedPatientsAppointments findDetailedAppointmentsByAppointmentId(Long appointmentId);

	@Query(value = "select  appointment_id, patient_id, firstname as patients_firstname, "
			+ "lastname as patients_lastname, email, doctor_id,"
			+ "(select firstname from users where users.users_id = patients_appointments.doctor_id) as doctors_firstname, "
			+ "(select lastname from users where users.users_id = patients_appointments.doctor_id) as doctors_lastname, "
			+ "(select email from users where users.users_id = patients_appointments.doctor_id) as doctors_email, "
			+ "appointment_date, appointment_time,appointment_status,"
			+ "feedback , doctors_ratings, patients_notes, prescription, created_time from users inner join patients_appointments "
			+ "on patients_appointments.patient_id = users.users_id "
			+ "order by appointment_id desc", nativeQuery = true)
	List<DetailedPatientsAppointments> findDetailedAppointmentsForAdmin();

	@Query(value = "select  appointment_id, patient_id, firstname as patients_firstname, " + 
			"lastname as patients_lastname, email, doctor_id, " + 
			"(select firstname from users where users.users_id = patients_appointments.doctor_id) as doctors_firstname, " + 
			"(select lastname from users where users.users_id = patients_appointments.doctor_id) as doctors_lastname, " + 
			"(select email from users where users.users_id = patients_appointments.doctor_id) as doctors_email, " + 
			"appointment_date, appointment_time,appointment_status, " + 
			"feedback , doctors_ratings, patients_notes, prescription, created_time "
			+ "from users inner join patients_appointments on patients_appointments.patient_id = users.users_id where patients_appointments.doctor_id = ?1", nativeQuery = true)
	List<DetailedPatientsAppointments> findDetailedAppointmentsForDoctor(Long doctorId);

	@Query(value = "select  appointment_id, patient_id, firstname as patients_firstname, "
			+ "lastname as patients_lastname, email, doctor_id,"
			+ "(select firstname from users where users.users_id = patients_appointments.doctor_id) as doctors_firstname, "
			+ "(select lastname from users where users.users_id = patients_appointments.doctor_id) as doctors_lastname, "
			+ "(select email from users where users.users_id = patients_appointments.doctor_id) as doctors_email, "
			+ "appointment_date, appointment_time,appointment_status,"
			+ "feedback , doctors_ratings, patients_notes, prescription, created_time from users inner join patients_appointments "
			+ "on patients_appointments.patient_id = users.users_id where patients_appointments.patient_id = ?1 "
			+ "order by appointment_id desc", nativeQuery = true)
	List<DetailedPatientsAppointments> findDetailedAppointmentsForPatient(Long patientId);

}
