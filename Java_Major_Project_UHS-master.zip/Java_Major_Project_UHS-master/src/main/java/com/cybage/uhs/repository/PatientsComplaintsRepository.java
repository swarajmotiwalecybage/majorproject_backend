package com.cybage.uhs.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cybage.uhs.model.PatientComplaints;

@Repository
public interface PatientsComplaintsRepository extends JpaRepository<PatientComplaints, Integer> {
	PatientComplaints findPatientComplaintsByPatientComplaintsId(Long patientComplaintsId);
	List<PatientComplaints> findPatientComplaintsByPatientId(Long patientId);
}
