package com.cybage.uhs.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;

import org.apache.pdfbox.io.IOUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.cybage.uhs.bean.APIResponseEntity;
import com.cybage.uhs.exception.FileStorageException;
import com.cybage.uhs.model.FilesModel;
import com.cybage.uhs.repository.FilesRepository;
import com.cybage.uhs.utils.ConstantMethods;
import com.cybage.uhs.utils.ConstantVars;

@Service
public class FilesService {

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private FilesRepository filesRepository;

	public APIResponseEntity uploadPrescription() {

		try (PDDocument doc = new PDDocument()) {

			PDPage myPage = new PDPage();
			doc.addPage(myPage);

			try (PDPageContentStream cont = new PDPageContentStream(doc, myPage)) {

				cont.beginText();

				cont.setFont(PDType1Font.HELVETICA, 12);
				cont.setLeading(14.5f);

				cont.newLineAtOffset(25, 700);
				String line1 = "World War II (often abbreviated to WWII or WW2), "
						+ "also known as the Second World War,";
				cont.showText(line1);

				cont.newLine();

				String line2 = "was a global war that lasted from 1939 to 1945, "
						+ "although related conflicts began earlier.";
				cont.showText(line2);
				cont.newLine();

				String line3 = "It involved the vast majority of the world's "
						+ "countries—including all of the great powers—";
				cont.showText(line3);
				cont.newLine();

				String line4 = "eventually forming two oA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencesA paragraph is a collection of words strung together to make a longer unit than a sentence. Several sentencespposing military "
						+ "alliances: the Allies and the Axis.";
				cont.showText(line4);
				cont.newLine();

				cont.endText();

			}
			doc.save("src/main/resources/wwii.pdf");
			File file = new java.io.File("src/main/resources/file.pdf");
			System.out.println(file.exists());
			byte[] fileContent = Files.readAllBytes(file.toPath());
			FileInputStream input = new FileInputStream(file);
			System.out.println("ddddd" + fileContent);

			MultipartFile multipartFile = new MockMultipartFile("file", file.getName(), "pdf/plain",
					IOUtils.toByteArray(input));

//			ByteArrayOutputStream baos = new ByteArrayOutputStream();
//			doc.save(baos);
//			doc.close();
//			// storeFile(cont.get);
//			System.out.println("---" + baos.toByteArray());
			storeFile(multipartFile, "trial");
		} catch (IOException e) {
			ConstantMethods.failureRespone("Could not upload file at this momentt.\n Try again later.");
		}
//		List<Users> allPatients = usersRepository.findUsersByUsersRoleId(usersRoleId);
		return ConstantMethods.successRespone(null, ConstantVars.ALL_PATIENTS_FETCHED_SUCCESSFULLY);
	}

	public FilesModel storeFile(MultipartFile file, String fileNamee) throws IOException {
		// Normalize file name
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());

		// Check if the file's name contains invalid characters
		if (fileName.contains("..")) {
			throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
		}

		FilesModel dbFile = new FilesModel(fileName, ".pdf", file.getBytes(), null);

		return filesRepository.save(dbFile);
	}

	public FilesModel getFile(Long fileId) {
		System.out.println("fhgsaaskhgd");
		FilesModel filesModel = filesRepository.findFilesModelByFilesModelId(fileId);
		System.out.println("asvasd" + filesModel.getPrescription());
		return filesModel;
	}

//	private APIResponseEntity sendVerificationLinkToUsersMailId(Users user, APIResponseEntity userResponse) {
//
//		
//		String toAddress = user.getEmail();
//		String fromAddress = "Trng2@evolvingsols.com";
//		String senderName = "Universal Health Services";
//		String subject = "Verify your account ";
//
//		String newContent = " <div style='font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2'>"
//				+ "  <div style='margin:50px auto;width:70%;padding:20px 0'>"
//				+ "    <div style='border-bottom:1px solid #eee'>"
//				+ "      <a href='' style='font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600'>Universal Health Services</a>"
//				+ "    </div>  <p style='font-size:1.1em'>Hi " + user.getFirstname() + " " + user.getLastname()
//				+ ",</p>"
//				+ "    <p>Thank you for choosing Universal Health Services. Use the following button to verify your account before loggin in.</p>"
//				+ "    <h2 style='background: #73c1d4;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;'>"
//				+ "    <a href='http://localhost:8085/users/activate-account/" + user.getUsersId()
//				+ "'> Verify Your Account <a></h2>" + "    <p style='font-size:0.9em;'>Regards,<br/>Your UHS</p>"
//				+ "    <hr style='border:none;border-top:1px solid #eee' />"
//				+ "    <div style='float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300'>"
//				+ "      <p>Universal Health Services Inc.</p>   <p>1600 Amphitheatre Parkway</p> <p>Pune</p>"
//				+ "    </div> </div>	";
//
//		MimeMessage message = mailSender.createMimeMessage();
//		MimeMessageHelper helper = new MimeMessageHelper(message);
//
//		try {
//			helper.setFrom(fromAddress, senderName);
//			helper.setTo(toAddress);
//			helper.setSubject(subject);
//			helper.setText(newContent, true);
//		} catch (UnsupportedEncodingException | MessagingException e) {
//			e.printStackTrace();
//			return ConstantMethods.failureRespone(ConstantVars.USER_REGISTERATION_FAILED);
//		}
//
//		mailSender.send(message);
//		return ConstantMethods.successRespone(user,ConstantVars.USER_REGISTERED_SUCCESSFULLY);
//
//	}
}
