package com.cybage.uhs.service;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.Date;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.cybage.uhs.bean.APIResponseEntity;
import com.cybage.uhs.model.DetailedPatientsAppointments;
import com.cybage.uhs.model.PatientsAppointments;
import com.cybage.uhs.repository.DetailedPatientApointmentsRepository;
import com.cybage.uhs.repository.PatientApointmentsRepository;
import com.cybage.uhs.utils.ConstantMethods;
import com.cybage.uhs.utils.ConstantVars;

@Service
public class PatientAppointmentsService {

	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	private PatientApointmentsRepository patientApointmentsRepository;
	@Autowired
	private DetailedPatientApointmentsRepository detailedPatientApointmentsRepository;
	static Logger logger = null;
	

	public APIResponseEntity addAppointment(PatientsAppointments patientsAppointments) {
		BasicConfigurator.configure();
		logger = Logger.getLogger(PatientAppointmentsService.class);
		patientsAppointments.setAppointmentStatus(ConstantVars.APPONTMENT_STATUS.PENDING.toString());
		patientsAppointments.setCreatedTime(new Timestamp(new Date().getTime()));
		PatientsAppointments newCreatedAppointment = patientApointmentsRepository.save(patientsAppointments);
		if (newCreatedAppointment.getAppointmentId() > 0) {
			logger.info(ConstantVars.APPOINTMENT_ADDED_SUCCESSFULLY);
			return ConstantMethods.successRespone( newCreatedAppointment, ConstantVars.APPOINTMENT_ADDED_SUCCESSFULLY);
		} else {
			logger.error(ConstantVars.APPOINTMENT_ADDED_FAILED);
			return ConstantMethods.failureRespone(ConstantVars.APPOINTMENT_ADDED_FAILED);
		}
	}

	public APIResponseEntity getAllPaitientsAppointments() {
		return ConstantMethods.successRespone(patientApointmentsRepository.findAll(),ConstantVars.ALL_APPOINTMENT_FETCHED_SUCCESSFULLY);
	}

	public APIResponseEntity getAppointmentById(Long appointmentId) {
		return ConstantMethods.successRespone(
			detailedPatientApointmentsRepository.findDetailedAppointmentsByAppointmentId(appointmentId), 
			ConstantVars.APPOINTMENT_FOR_ADMIN_FETCHED_SUCCESSFULLY);
	}
	public APIResponseEntity getAllAppointmentsForAdmin() {
		return ConstantMethods.successRespone(
				detailedPatientApointmentsRepository.findDetailedAppointmentsForAdmin(), 
				ConstantVars.APPOINTMENT_FOR_ADMIN_FETCHED_SUCCESSFULLY);
	}

	public APIResponseEntity getAllAppointmentsForDoctor(Long doctorId) {
		return ConstantMethods.successRespone(
			detailedPatientApointmentsRepository.findDetailedAppointmentsForDoctor(doctorId), 
			ConstantVars.APPOINTMENT_FOR_DOCTOR_FETCHED_SUCCESSFULLY);
	}

	public APIResponseEntity getAllAppointmentsForPatient(Long patientId) {
		return ConstantMethods.successRespone(
			detailedPatientApointmentsRepository.findDetailedAppointmentsForPatient(patientId), 
			ConstantVars.APPOINTMENT_FOR_PATIENT_FETCHED_SUCCESSFULLY);
	}

	public APIResponseEntity changeAppointmentStatus(Long appointmentId, String newStatus) {
		PatientsAppointments patientsAppointments = patientApointmentsRepository
				.findPatientsAppointmentsByAppointmentId(appointmentId);
		if (patientsAppointments != null) {
			return ConstantMethods.successRespone( patientsAppointments, ConstantVars.APPOINTMENT_STATUS_UPDATED_SUCCESSFULLY);
		} else {
			return ConstantMethods.failureRespone(ConstantVars.APPOINTMENT_IVALID_ID);
		}
	}

	public APIResponseEntity updateAppointment(PatientsAppointments patientsAppointments, Long appointmentId) {
		patientsAppointments.setAppointmentId(appointmentId);
		PatientsAppointments updatedPatientsAppointments = patientApointmentsRepository.save(patientsAppointments);
		if (updatedPatientsAppointments != null) {
			return ConstantMethods.successRespone( updatedPatientsAppointments, ConstantVars.APPOINTMENT_STATUS_UPDATED_SUCCESSFULLY);
		} else {
			return ConstantMethods.failureRespone(ConstantVars.APPOINTMENT_IVALID_ID);
		}
	}

	public APIResponseEntity getPatientsAppointmentById(Long appointmentId) {
		return ConstantMethods.successRespone(
				detailedPatientApointmentsRepository.findDetailedAppointmentsByAppointmentId(appointmentId),
				ConstantVars.APPOINTMENT_FETCHED_SUCCESSFULLY);
	}

	public APIResponseEntity addAppointmentsPrescription(PatientsAppointments patientsAppointments, Long appointmentId) {
		patientsAppointments.setAppointmentId(appointmentId);
		patientsAppointments.setAppointmentStatus("COMPLETED");
		PatientsAppointments prescriptionAddedAppointment = patientApointmentsRepository.save(patientsAppointments);
		if (prescriptionAddedAppointment != null) {
			DetailedPatientsAppointments appointment = detailedPatientApointmentsRepository.findDetailedAppointmentsByAppointmentId(appointmentId);
			return sendPrescriptionDetailsOnMail(appointment);
		} else {
			return ConstantMethods.failureRespone(ConstantVars.APPOINTMENT_PRESCRIPTION_UPDATION_FAILED);
		}
	}
	
	
	
	private APIResponseEntity sendPrescriptionDetailsOnMail(DetailedPatientsAppointments appointment) {
		String toAddress = appointment.getEmail();
		String fromAddress = "Trng2@evolvingsols.com";
		String senderName = "Universal Health Services";
		String subject = "Updates on Appointment";
// @formatter:off
		String newContent = " <div style='font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2'>"
				+ "  <div style='margin:50px auto;width:70%;padding:20px 0'>"
				+ "    <div style='border-bottom:1px solid #eee'>"
				+ "      <a href='' style='font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600'>Universal Health Services</a>"
				+ "    </div>  <p style='font-size:1.1em'>Hi " + appointment.getPatientsFirstname() + " " + appointment.getPatientsLastname()
				+ "		,</p>"
				+ "    <p >Your appointment has been completed.  </p>"
				+ "    <p style='font-size:1.1em'> Please find below the details of your appointment:</p>"
				+ "		Doctor name: " + appointment.getDoctorsFirstname() + " " + appointment.getDoctorsLastname() + "</br>" 
				+ "		Appointment date: " + appointment.getAppointmentDate() + "</br> "
				+ "		Appointment time: " + appointment.getAppointmentTime() + "</br> "
				+ "		Appointment Status: " + appointment.getAppointmentStatus() + "</br> "
				+ "		Appointment Created on: " + appointment.getCreatedTime()  + "</br>"
				+ "     Prescription: " + appointment.getPrescription()
				+ "     <br/> <p style='font-size:0.9em;'>Regards,<br/>Your UHS</p>"
				+ "    <hr style='border:none;border-top:1px solid #eee' />"
				+ "    <div style='float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300'>"
				+ "      <p>Universal Health Services Inc.</p>   <p>1600 Amphitheatre Parkway</p> <p>Pune</p>"
				+ "    </div> </div>	";
 
// @formatter:on

		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);

		try {
			helper.setFrom(fromAddress, senderName);
			helper.setTo(toAddress);
			helper.setSubject(subject);
			helper.setText(newContent, true);
		} catch (UnsupportedEncodingException | MessagingException e) {
			e.printStackTrace();
			return ConstantMethods.failureRespone(ConstantVars.APPOINTMENT_PRESCRIPTION_UPDATION_FAILED);
		}
		mailSender.send(message);
		return ConstantMethods.successRespone(appointment, ConstantVars.APPOINTMENT_PRESCRIPTION_UPDATED_SUCCESSFULLY);
	}

}
