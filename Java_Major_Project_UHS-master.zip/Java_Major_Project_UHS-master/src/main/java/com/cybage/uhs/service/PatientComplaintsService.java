package com.cybage.uhs.service;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.Date;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.cybage.uhs.bean.APIResponseEntity;
import com.cybage.uhs.model.PatientComplaints;
import com.cybage.uhs.model.Users;
import com.cybage.uhs.model.UsersAccountStatusEntity;
import com.cybage.uhs.repository.PatientsComplaintsRepository;
import com.cybage.uhs.repository.UsersAccountStatusRepository;
import com.cybage.uhs.repository.UsersRepository;
import com.cybage.uhs.utils.ConstantMethods;
import com.cybage.uhs.utils.ConstantVars;

@Service
public class PatientComplaintsService {

	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	private UsersRepository usersRepository;
	@Autowired
	private PatientsComplaintsRepository patientComplaintsRepository;
	@Autowired
	private UsersAccountStatusRepository usersAccountStatusRepository;

	public APIResponseEntity getAllComplaints() {
		return ConstantMethods.successRespone(patientComplaintsRepository.findAll(), "");
	}

	public APIResponseEntity getComplaintById(Long patientComplaintsId) {
		PatientComplaints complaint = patientComplaintsRepository
				.findPatientComplaintsByPatientComplaintsId(patientComplaintsId);
		return ConstantMethods.successRespone(complaint, "");
	}

	public APIResponseEntity updateComplaint(PatientComplaints complaint, Long patientComplaintsId) {
		complaint.setPatientComplaintsId(patientComplaintsId);
		complaint.setComplaintStatus(ConstantVars.COMPLAINT_STATUS.RESOLVED.toString());
		PatientComplaints patientComplaints = patientComplaintsRepository.save(complaint);
		Users user = usersRepository.findUsersByUsersId(complaint.getPatientId());
		return sendUpdatedComplaintDetailsOnMail(patientComplaints, user);
	}

	public APIResponseEntity addComplaint(PatientComplaints patientComplaints) {
		patientComplaints.setComplaintStatus(ConstantVars.COMPLAINT_STATUS.PENDING.toString());
		patientComplaints.setCreatedTime(new Timestamp(new Date().getTime()));
		patientComplaints.setReminderSent(0);
		PatientComplaints newPatientComplaints = patientComplaintsRepository.save(patientComplaints);
		Users patientsDetails = usersRepository.findUsersByUsersId(newPatientComplaints.getPatientId());
		return sendComplaintDetailsOnMail(newPatientComplaints, patientsDetails);
	}

	private APIResponseEntity sendComplaintDetailsOnMail(PatientComplaints complaint, Users user) {
		String toAddress = user.getEmail();
		String fromAddress = "Trng2@evolvingsols.com";
		String senderName = "Universal Health Services";
		String subject = "Complaint Details Update";
		Date complaintRegisterdDate = complaint.getCreatedTime();
		
		String newContent = " <div style='font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2'>"
				+ "  <div style='margin:50px auto;width:70%;padding:20px 0'>"
				+ "    <div style='border-bottom:1px solid #eee'>"
				+ "      <a href='' style='font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600'>Universal Health Services</a>"
				+ "    </div>  <p style='font-size:1.1em'>Hi " + user.getFirstname() + " " + user.getLastname()
				+ "		,</p>"
				+ "    <p>Your complaint has been resolved. "
				+ " 	We are sorry for the inconvenience.</p>"
				+ "    <p> Please find below the updates on your complaint:</p>"
				+ "		Description: " + complaint.getComplaintDescription()  + "</br>"
				+ "		Type: " + complaint.getComplaintType() + "</br> "
				+ "		Status: " + complaint.getComplaintStatus() + "</br> "
				+ "		Created on: " + complaintRegisterdDate  
				+ "     <br/> <p style='font-size:0.9em;'>Regards,<br/>Your UHS</p>"
				+ "    <hr style='border:none;border-top:1px solid #eee' />"
				+ "    <div style='float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300'>"
				+ "      <p>Universal Health Services Inc.</p>   <p>1600 Amphitheatre Parkway</p> <p>Pune</p>"
				+ "    </div> </div>	";
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);

		try {
			helper.setFrom(fromAddress, senderName);
			helper.setTo(toAddress);
			helper.setSubject(subject);
			helper.setText(newContent, true);
		} catch (UnsupportedEncodingException | MessagingException e) {
			e.printStackTrace();
			return ConstantMethods.failureRespone(ConstantVars.COMPLAINT_REGISTERATION_FAILED);
		}

		mailSender.send(message);
		return ConstantMethods.successRespone(complaint, ConstantVars.COMPLAINT_REGISTERED_SUCCESSFULLY);
	}
	
	private APIResponseEntity sendUpdatedComplaintDetailsOnMail(PatientComplaints complaint, Users user) {
		String toAddress = user.getEmail();
		String fromAddress = "Trng2@evolvingsols.com";
		String senderName = "Universal Health Services";
		String subject = "Complaint Details";
		Date complaintRegisterdDate = complaint.getCreatedTime();
		
		String newContent = " <div style='font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2'>"
				+ "  <div style='margin:50px auto;width:70%;padding:20px 0'>"
				+ "    <div style='border-bottom:1px solid #eee'>"
				+ "      <a href='' style='font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600'>Universal Health Services</a>"
				+ "    </div>  <p style='font-size:1.1em'>Hi " + user.getFirstname() + " " + user.getLastname()
				+ "		,</p>"
				+ "    <p> Your complaint has been created. We will send you updates on your email."
				+ " 	We are sorry for the inconvenience.</p>"
				+ "    <p> Please find below your complaint's details:</p>"
				+ "		Description: " + complaint.getComplaintDescription()  + "</br>"
				+ "		Type: " + complaint.getComplaintType() + "</br> "
				+ "		Updated Status: " + complaint.getComplaintStatus() + "</br> "
				+ "		Response: " + complaint.getAdminReply() + "</br> "
				+ "		Created on: " + complaintRegisterdDate  
				+ "     <br/> <p style='font-size:0.9em;'>Regards,<br/>Your UHS</p>"
				+ "    <hr style='border:none;border-top:1px solid #eee' />"
				+ "    <div style='float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300'>"
				+ "      <p>Universal Health Services Inc.</p>   <p>1600 Amphitheatre Parkway</p> <p>Pune</p>"
				+ "    </div> </div>	";
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);

		try {
			helper.setFrom(fromAddress, senderName);
			helper.setTo(toAddress);
			helper.setSubject(subject);
			helper.setText(newContent, true);
		} catch (UnsupportedEncodingException | MessagingException e) {
			e.printStackTrace();
			return ConstantMethods.failureRespone(ConstantVars.COMPLAINT_UPDATION_FAILED);
		}

		mailSender.send(message);
		return ConstantMethods.successRespone(complaint, ConstantVars.COMPLAINT_UPDATED_SUCCESSFULLY);
	}

	public APIResponseEntity getComplaintsPatientById(Long patientId) {
		return ConstantMethods.successRespone(patientComplaintsRepository.findPatientComplaintsByPatientId(patientId), "");
	}

	public APIResponseEntity sendReminder(Long patientComplaintsId) {
		PatientComplaints complaint =
				patientComplaintsRepository.findPatientComplaintsByPatientComplaintsId(patientComplaintsId);
		Users user = usersRepository.findUsersByUsersId(complaint.getPatientId());
		UsersAccountStatusEntity userAccountStatus =
				usersAccountStatusRepository.findUsersAccountStatusEntityByUsersAccountStatusId(user.getAccountStatus());
		String toAddress = "chaitanyadeshm@cybage.com";
		String fromAddress = "Trng2@evolvingsols.com";
		String senderName = "Universal Health Services";
		String subject = "Complaint's Reminder";
		Date complaintRegisterdDate = complaint.getCreatedTime();
		
		String newContent = " <div style='font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2'>"
				+ "  <div style='margin:50px auto;width:70%;padding:20px 0'>"
				+ "    <div style='border-bottom:1px solid #eee'>"
				+ "      <a href='' style='font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600'>Universal Health Services</a>"
				+ "    </div>  <p style='font-size:1.1em'>Hi Admin,</p>"
				+ "    <p>The below complaint is not yet resolved yet:</p>"
				+ "		Full Name: " + user.getFirstname() + " " + user.getLastname()  + "</br>"
				+ "		Email: " + user.getEmail() + "</br>"
				+ "		Contact no.: " + user.getMobile() + "</br>"
				+ "		User's current account status.: " + userAccountStatus.getStatus() + "</br>"
				+ "		Description: " + complaint.getComplaintDescription()  + "</br>"
				+ "		Type: " + complaint.getComplaintType() + "</br> "
				+ "		Status: " + complaint.getComplaintStatus() + "</br> "
				+ "		Created on: " + complaintRegisterdDate  
				+ "     <br/> <p style='font-size:0.9em;'>Regards,<br/>Your UHS</p>"
				+ "    <hr style='border:none;border-top:1px solid #eee' />"
				+ "    <div style='float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300'>"
				+ "      <p>Universal Health Services Inc.</p>   <p>1600 Amphitheatre Parkway</p> <p>Pune</p>"
				+ "    </div> </div>	";
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);

		try {
			helper.setFrom(fromAddress, senderName);
			helper.setTo(toAddress);
			helper.setSubject(subject);
			helper.setText(newContent, true);
		} catch (UnsupportedEncodingException | MessagingException e) {
			e.printStackTrace();
			return ConstantMethods.failureRespone(ConstantVars.COMPLAINT_REMINDER_SENT_FAILED);
		}

		mailSender.send(message);
		return ConstantMethods.successRespone(complaint, ConstantVars.COMPLAINT_REMINDER_SENT_SUCCESSFULLY);
	}

}
