package com.cybage.uhs.service;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.cybage.uhs.bean.APIResponseEntity;
import com.cybage.uhs.exception.RecordException;
import com.cybage.uhs.model.Doctor;
import com.cybage.uhs.model.DoctorsSpecialization;
import com.cybage.uhs.model.Specialization;
import com.cybage.uhs.model.Users;
import com.cybage.uhs.model.UsersAccountStatusEntity;
import com.cybage.uhs.repository.DoctorsSpecializationRepository;
import com.cybage.uhs.repository.SpecializationRepository;
import com.cybage.uhs.repository.UsersAccountStatusRepository;
import com.cybage.uhs.repository.UsersRepository;
import com.cybage.uhs.utils.ConstantMethods;
import com.cybage.uhs.utils.ConstantVars;

@Service
public class UsersService {

	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	private UsersRepository usersRepository;
	@Autowired
	private SpecializationRepository specializationRepository;
	@Autowired
	private DoctorsSpecializationRepository doctorsSpecializationRepository;
	@Autowired
	private UsersAccountStatusRepository usersAccountStatusRepository;
	Logger logger = LogManager.getLogger(UsersService.class);

	public APIResponseEntity getAllUsers() {
		List<Users> allUsers = usersRepository.findAll();
		return ConstantMethods.successRespone(allUsers, ConstantVars.ALL_USERS_FETCHED_SUCCESSFULLY);
	}

	public APIResponseEntity getAllUsersByAcountStatus(String accountStatus) {
		UsersAccountStatusEntity usersAccountStatus = usersAccountStatusRepository.findUsersAccountStatusEntityByStatus(accountStatus);
		if (usersAccountStatus != null) {
			List<Users> usersByAccountStatus = usersRepository.findUsersByAccountStatus(usersAccountStatus.getUsersAccountStatusId());
			logger.info(ConstantVars.ALL_USERS_BY_ACCOUNT_STATUS_FETCHED_SUCCESSFULLY);
			return ConstantMethods.successRespone(usersByAccountStatus,
					ConstantVars.ALL_USERS_BY_ACCOUNT_STATUS_FETCHED_SUCCESSFULLY);
		} else {
			logger.warn(ConstantVars.ALL_USERS_BY_ACCOUNT_STATUS_FETCHED_FAILED);
			return ConstantMethods.failureRespone(ConstantVars.ALL_USERS_BY_ACCOUNT_STATUS_FETCHED_FAILED);
		}
	}

	public APIResponseEntity getAllPatients() {
		List<Users> allPatients = usersRepository.findUsersByUsersRoleId(3);
		logger.info(ConstantVars.ALL_PATIENTS_FETCHED_SUCCESSFULLY);
		return ConstantMethods.successRespone(allPatients, ConstantVars.ALL_PATIENTS_FETCHED_SUCCESSFULLY);
	}

	public APIResponseEntity getAllDoctors() {
		List<Users> allDoctors = usersRepository.findUsersByUsersRoleId(2);
		return fetchAllDoctors(allDoctors);
	}

	private APIResponseEntity fetchAllDoctors(List<Users> allDoctors) {
		List<Doctor> doctorsData = new ArrayList<Doctor>();
		for (Users user : allDoctors) {
			Doctor doctor = new Doctor(user.getUsersId(), user.getUsersRoleId(), user.getFirstname(),
					user.getLastname(), user.getEmail(), user.getAccountStatus(), user.getUsersProfileUrl(),
					user.getMobile(), user.getLoginAttempts(), user.getAccountCreated(), user.getUsersOTP());
			List<Specialization> allSpecialization = returnSpecializationFromDoctorsId(user.getUsersId());
			doctor.setSpecializations(allSpecialization);
			doctorsData.add(doctor);
		}

		return ConstantMethods.successRespone(doctorsData, "All doctors fetched successfully.");
	}

	private List<Specialization> findSpecializationOfDoctor(Long doctorId) {
		List<DoctorsSpecialization> allSpecialization = doctorsSpecializationRepository
				.findDoctorsSpecializationByDoctorId(doctorId);
		List<Integer> allSpecializationIds = new ArrayList<Integer>();
		for (DoctorsSpecialization specialization : allSpecialization)
			allSpecializationIds.add(specialization.getSpecializationId());
		return specializationRepository.findSpecializationBySpecializationIdIn(allSpecializationIds);
	}

	public APIResponseEntity getAllUsersAccordingToRole(int usersRoleId) {
		List<Users> allPatients = usersRepository.findUsersByUsersRoleId(usersRoleId);
		return ConstantMethods.successRespone(allPatients, ConstantVars.ALL_PATIENTS_FETCHED_SUCCESSFULLY);
	}

	public APIResponseEntity addUser(Users user) {
		APIResponseEntity userResponse = new APIResponseEntity();
		user.setAccountCreated(new Timestamp(new Date().getTime()));
		user.setAccountStatus(2);
		user.setUsersOTP(null);
		user.setLoginAttempts(null);
		if (usersRepository.existsByEmail(user.getEmail())) {
			return ConstantMethods.failureRespone(ConstantVars.USER_REGISTERATION_FAILED);
		} else {
			Users newRegisteredUser = usersRepository.save(user);
			if (newRegisteredUser != null) {
				return sendVerificationLinkToUsersMailId(newRegisteredUser, userResponse);
			} else {
				return ConstantMethods.failureRespone(ConstantVars.USER_ALREADY_REGISTERED);
			}
		}

	}

	private APIResponseEntity sendVerificationLinkToUsersMailId(Users user, APIResponseEntity userResponse) {
		String recieversEmail = user.getEmail();
		String sendersEmail = "Trng2@evolvingsols.com";
		String senderName = "Universal Health Services";
		String subject = "Verify your account ";
//@// @formatter:off
 		String newContent = " <div style='font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2'>"
				+ "  <div style='margin:50px auto;width:70%;padding:20px 0'>"
				+ "    <div style='border-bottom:1px solid #eee'>"
				+ "      <a href='' style='font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600'>Universal Health Services</a>"
				+ "    </div>  <p style='font-size:1.1em'>Hi, " + user.getFirstname() + " " + user.getLastname()
				+ ",</p>"
				+ "    <p>Thank you for choosing Universal Health Services. Use the following button to verify your account before loggin in.</p>"
				+ "    <h2 style='background: #73c1d4;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;'>"
				+ "    <a href='http://localhost:8085/users/activate-account/" + user.getUsersId()
				+ "'> Verify Your Account <a></h2>" + "    <p style='font-size:0.9em;'>Regards,<br/>Your UHS</p>"
				+ "    <hr style='border:none;border-top:1px solid #eee' />"
				+ "    <div style='float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300'>"
				+ "      <p>Universal Health Services Inc.</p>   <p>1600 Amphitheatre Parkway</p> <p>Pune</p>"
				+ "    </div> </div>	";
		// @formatter:on

		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);

		try {
			helper.setFrom(sendersEmail, senderName);
			helper.setTo(recieversEmail);
			helper.setSubject(subject);
			helper.setText(newContent, true);
		} catch (UnsupportedEncodingException | MessagingException e) {
			e.printStackTrace();
			new RecordException(ConstantVars.USER_REGISTERATION_FAILED);
			return ConstantMethods.failureRespone(ConstantVars.USER_REGISTERATION_FAILED);
		}

		mailSender.send(message);
		return ConstantMethods.successRespone(user, ConstantVars.USER_REGISTERED_SUCCESSFULLY);

	}

	public String activateAccount(Long usersId) {
		Users user = usersRepository.findUsersByUsersId(usersId);
		if (user != null) {
			user.setAccountStatus(1);
			usersRepository.save(user);
			return ConstantVars.EMAIL_VERIFIED_PAGE;
		} else
			return ConstantVars.ERROR_RESPONSE;

	}

	public APIResponseEntity addDoctor(Doctor doctor) {
		if (usersRepository.existsByEmail(doctor.getEmail())) {
			return ConstantMethods.failureRespone(ConstantVars.USER_REGISTERATION_FAILED);
		} else {
			Users userAsDoctor = new Users(doctor.getFirstname(), doctor.getLastname(), doctor.getEmail(),
					doctor.getUsersProfileUrl(), doctor.getMobile());
			userAsDoctor.setAccountCreated(new Timestamp(new Date().getTime()));
			userAsDoctor.setAccountStatus(usersAccountStatusRepository
					.findUsersAccountStatusEntityByStatus(ConstantVars.ACCOUNT_STATUS.ACTIVE.toString())
					.getUsersAccountStatusId());
			userAsDoctor.setUsersOTP(null);
			userAsDoctor.setUsersRoleId(2);
			userAsDoctor.setLoginAttempts(null);
			Users registeredDoctor = usersRepository.save(userAsDoctor);
			Doctor newDoctor = new Doctor(registeredDoctor.getUsersId(), registeredDoctor.getUsersRoleId(),
					registeredDoctor.getFirstname(), registeredDoctor.getLastname(), registeredDoctor.getEmail(),
					registeredDoctor.getAccountStatus(), registeredDoctor.getUsersProfileUrl(),
					registeredDoctor.getMobile(), registeredDoctor.getLoginAttempts(),
					registeredDoctor.getAccountCreated(), registeredDoctor.getUsersOTP());
			newDoctor.setSpecializationsId(doctor.getSpecializationsId());
			List<DoctorsSpecialization> doctorsSpecializations = new ArrayList<DoctorsSpecialization>();
			if (doctor.getSpecializationsId() != null) {
				if (registeredDoctor != null) {
					for (int i = 0; i < doctor.getSpecializationsId().size(); i++) {
						doctorsSpecializations.add(new DoctorsSpecialization(registeredDoctor.getUsersId(),
								doctor.getSpecializationsId().get(i)));
					}
					doctorsSpecializationRepository.saveAll(doctorsSpecializations);
					List<Specialization> allSpecializations = returnSpecializationFromDoctorsId(
							registeredDoctor.getUsersId());
					newDoctor.setSpecializations(allSpecializations);
					return sendDoctorsCredentials(newDoctor);
				}
			}

		}
		return ConstantMethods.failureRespone(ConstantVars.DOCTOR_REGISTERED_FAILED);
	}

	public APIResponseEntity sendDoctorsCredentials(Doctor doctor) {
		String recieversEmail = doctor.getEmail();
		String sendersEmail = "Trng2@evolvingsols.com";
		String senderName = "Universal Health Services";
		String subject = "Login Credentials";
		String doctorsMailContent = ConstantMethods.sendDoctorsCredentialsOnMailHTML(doctor);
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);
		try {
			helper.setFrom(sendersEmail, senderName);
			helper.setTo(recieversEmail);
			helper.setSubject(subject);
			helper.setText(doctorsMailContent, true);
		} catch (UnsupportedEncodingException | MessagingException e) {
			e.printStackTrace();
			return ConstantMethods.failureRespone(ConstantVars.DOCTOR_REGISTERED_FAILED);
		}
		mailSender.send(message);
		return ConstantMethods.successRespone(doctor, ConstantVars.DOCTOR_REGISTERED_SUCCESSFULLY);
	}

	public APIResponseEntity getUserById(Long usersId) {
		Users user = usersRepository.findUsersByUsersId(usersId);
		if (user.getUsersRoleId() == 2) {
			return fetchDoctorDetails(user);
		}
		return ConstantMethods.successRespone(usersRepository.findUsersByUsersId(usersId),
				"Users Data fetched successfully.");
	}

	private APIResponseEntity fetchDoctorDetails(Users user) {
		Doctor doctor = new Doctor(user.getUsersId(), user.getUsersRoleId(), user.getFirstname(), user.getLastname(),
				user.getEmail(), user.getAccountStatus(), user.getUsersProfileUrl(), user.getMobile(),
				user.getLoginAttempts(), user.getAccountCreated(), user.getUsersOTP());
		List<Specialization> allSpecialization = returnSpecializationFromDoctorsId(user.getUsersId());
		doctor.setSpecializations(allSpecialization);
		return ConstantMethods.successRespone(doctor, "Users Data fetched successfully.");
	}

	public APIResponseEntity deleteUserById(Long usersId) {
		Users user = usersRepository.findUsersByUsersId(usersId);
		UsersAccountStatusEntity usersAccountStatusEntity = usersAccountStatusRepository
				.findUsersAccountStatusEntityByStatus(ConstantVars.ACCOUNT_STATUS.DELETED.toString());
		if (user.getAccountStatus() == usersAccountStatusEntity.getUsersAccountStatusId()) {
			return ConstantMethods.failureRespone(ConstantVars.USER_DELETED_FAILED);
		} else {
			user.setAccountStatus(usersAccountStatusEntity.getUsersAccountStatusId());
			usersRepository.save(user);
			return ConstantMethods.successRespone(user, ConstantVars.USER_DELETED_SUCCESS);
		}
	}

	public APIResponseEntity loginUserByEmail(String email) {
		Users user = usersRepository.findUsersByEmail(email);
		if (user != null && user.getUsersId() != null) {
			if (user.getAccountStatus() == 2) {
				return ConstantMethods.failureRespone(ConstantVars.VERIFY_ACCOUNT_BEFORE_LOGIN);
			} else if (user.getAccountStatus() == 3) {
				return ConstantMethods.failureRespone(ConstantVars.ACCOUNT_BLOCKED);
			} else if (user.getAccountStatus() == 4) {
				return ConstantMethods.failureRespone(ConstantVars.ACCOUNT_BLOCKED_BY_ADMIN);
			} else if (user.getAccountStatus() == 5) {
				return ConstantMethods.failureRespone(ConstantVars.ACCOUNT_DELETED);
			}
			user.setUsersOTP(ConstantMethods.generateOtp());
			usersRepository.save(user);
			boolean isOTPSentSUccessfully = sendOTP(user);
			if (isOTPSentSUccessfully)
				return ConstantMethods.successRespone(user, ConstantVars.OTP_SENT_SUCCESSFULLY);
			else
				return ConstantMethods.failureRespone(ConstantVars.SOMETHING_WENT_WRONG);
		} else {
			return ConstantMethods.failureRespone(ConstantVars.USER_NOT_FOUND);
		}
	}

	public APIResponseEntity verifyLoginWithOTPResponse(String email, int otp) {
		Users user = usersRepository.findUsersByEmail(email);
		if (user.getAccountStatus() == 3) {
			return ConstantMethods.failureRespone(ConstantVars.ACCOUNT_BLOCKED);
		}
		if (user.getUsersOTP() == otp) {
			user.setUsersOTP(null);
			usersRepository.save(user);
			return ConstantMethods.successRespone(user, ConstantVars.OTP_VERIFIED_SUCCESSFULLY);
		} else {
			int remainingAttempt;
			remainingAttempt = ConstantVars.MAX_LOGIN_ATTEMPTS_ALLOWED - 1;
			if (user.getLoginAttempts() == null) {
				user.setLoginAttempts(remainingAttempt);
				usersRepository.save(user);
				return ConstantMethods.failureRespone(ConstantVars.WRONG_OTP_ENTERED + "\nYou have " + remainingAttempt
						+ " attempt(s) to enter correct OTP.");
			} else if (user.getLoginAttempts() == 0) {
				user.setLoginAttempts(null);
				user.setAccountStatus(3);
				usersRepository.save(user);
				return ConstantMethods.failureRespone(ConstantVars.MAX_OTP_ENTERED_EXCEEDED);
			} else {
				remainingAttempt = user.getLoginAttempts() - 1;
				user.setLoginAttempts(remainingAttempt);
				usersRepository.save(user);
				return ConstantMethods.failureRespone(ConstantVars.WRONG_OTP_ENTERED + "\nYou have " + remainingAttempt
						+ " attempts to enter correct OTP.");
			}
		}
	}

	public boolean sendOTP(Users user) {
		String recieversEmail = user.getEmail();
		String sendersEmail = "Trng2@evolvingsols.com";
		String senderName = "Universal Health Services";
		String subject = "OTP for Sign In to your account ";

		String newContent = " <div style='font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2'>"
				+ "  	<div style='margin:50px auto;width:70%;padding:20px 0'>"
				+ "    <div style='border-bottom:1px solid #eee'>"
				+ "      <a href='' style='font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600'>Universal Health Services</a>"
				+ "    </div>  <p style='font-size:1.1em'>Hi,</p>"
				+ "    <p>Thank you for choosing UHS. Use the following OTP to login to your account.</p>"
				+ "    <h2 style='background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;'>"
				+ user.getUsersOTP() + "</h2>"
				+ "    <p style='font-size:0.9em;'>Regards,<br/>Universal Health Services</p>"
				+ "    <hr style='border:none;border-top:1px solid #eee' />"
				+ "    <div style='float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300'>"
				+ "      <p>Universal Health Services Inc.</p>   <p>1600 Amphitheatre Parkway</p> <p>Pune</p>"
				+ "    </div> </div>	";

		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);
		try {
			helper.setFrom(sendersEmail, senderName);
			helper.setTo(recieversEmail);
			helper.setSubject(subject);
			helper.setText(newContent, true);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return false;
		} catch (MessagingException e) {
			e.printStackTrace();
			return false;
		}
		mailSender.send(message);
		return true;
	}

	public APIResponseEntity updateUser(Users user, Long usersId) {
		user.setUsersId(usersId);
		Users updatedUser = usersRepository.save(user);
		if (updatedUser != null)
			return ConstantMethods.successRespone(updatedUser, ConstantVars.USER_UPDATED_SUCCESSFULLY);
		else
			return ConstantMethods.failureRespone(ConstantVars.USER_UPDATED_FAILED);
	}

	public APIResponseEntity getAllDoctorsAccordingToSpecialization(int specializationId) {
		List<Users> doctorsAccordingToSpecialization = usersRepository.listOfUsersBySpecialization(specializationId);
		return ConstantMethods.successRespone(doctorsAccordingToSpecialization,
				ConstantVars.DOCTOR__ACCORDING_TO_SPECIALIZATION_FETCHED_SUCCESSFULLY);
	}

	public APIResponseEntity unblockeUsersAccount(Long usersId) {
		Users user = usersRepository.findUsersByUsersId(usersId);
		if (user != null) {
			UsersAccountStatusEntity usersAccountStatus = usersAccountStatusRepository
					.findUsersAccountStatusEntityByStatus(ConstantVars.ACCOUNT_STATUS.ACTIVE.toString());
			user.setAccountStatus(usersAccountStatus.getUsersAccountStatusId());
			return ConstantMethods.successRespone(user, ConstantVars.USER_UNBLOCKED_SUCCESSFULLY);
		} else
			return ConstantMethods.failureRespone(ConstantVars.USER_UNBLOCKED_FAILED);
	}

	private List<Specialization> returnSpecializationFromDoctorsId(Long doctorId) {
		List<DoctorsSpecialization> doctorsAllSpecialization = doctorsSpecializationRepository
				.findDoctorsSpecializationByDoctorId(doctorId);
		List<Integer> allSpecializationIds = new ArrayList<Integer>();
		List<Specialization> allSpecializations = new ArrayList<Specialization>();
		for (DoctorsSpecialization specialization : doctorsAllSpecialization)
			allSpecializationIds.add(specialization.getSpecializationId());
		allSpecializations = specializationRepository.findSpecializationBySpecializationIdIn(allSpecializationIds);
		return allSpecializations;
	}

}
