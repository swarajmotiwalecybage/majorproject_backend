package com.cybage.uhs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversalHealthServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
