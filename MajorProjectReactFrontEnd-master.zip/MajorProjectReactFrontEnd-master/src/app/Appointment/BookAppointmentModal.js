import axios from 'axios';
import React, { useEffect, useState } from 'react';
// import { MenuItem } from 'react-bootstrap';
import { Dropdown, Form } from 'react-bootstrap';
import ReactDatePicker from 'react-datepicker';
import Moment from 'react-moment';
import { addAppointmentURL, getAllDoctorsBySpecialization, getAllSpecialization, getAppointmentById, login, usersId } from '../utils/AllAPIS';

export const BookAppointmentModal = ({ toggleBookAppointmentModal, appointments, setAppointment }) => {
    const [isSpecializationSelected, setIsSpecializationSelected] = useState(false)
    const [specializations, setSpecializations] = useState([])
    const [selectedSpecialization, setSelectedSpecialization] = useState()
    const [selectedDoctor, setSelectedDoctor] = useState()
    const [doctors, setDoctors] = useState([])
    const [isDoctorSelected, setIsDoctorSelected] = useState(false)
    const [appointmentTime, setAppointmentTime] = useState("12:00")
    const [appointmentDate, setAppointmentDate] = useState(new Date())
    const [{ patientsNotes }, updateNotesInputFields] =
        useState({ patientsNotes: "" })
    const handlePatienstNotesChange = (event) => {
        const { name, value } = event.target;
        updateNotesInputFields((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    }
    useEffect(() => {
        if (sessionStorage.getItem(login)) {
        axios.get(getAllSpecialization).then((response) => {
            if (response.data.status && response.data.data) {
                setSpecializations(response.data.data)
            } else {
                alert(response.data.message)
            }
        })}
    }, [])

    const specializationSelected = eventkey => {
        if (Number(eventkey) !== 0) {
            setSelectedSpecialization(
                specializations.filter(specialization => Number(specialization.specializationId) === eventkey)
            )
            axios.get(`${getAllDoctorsBySpecialization}/${eventkey}`).then((response) => {
                if (response.data.status) {
                    setDoctors(response.data.data)
                    setIsSpecializationSelected(true)
                }
            })
        }
    };
    const doctorSelected = eventkey => {
        if (eventkey !== 0) {
            setSelectedDoctor(doctors.filter(doctor => Number(doctor.usersId) === eventkey))
            setIsDoctorSelected(true)
        }
    };
    const handleTimeChange = (eventKey, event) => {
        setAppointmentTime(event.target.innerHTML)
    }
    const handleAppointmentDateChange = date => {
        setAppointmentDate(date);
    };
    const bookAppointment = event => {
        event.preventDefault()
        let date = appointmentDate.getDate();
        if (`${appointmentDate.getDate()}`.length === 1) {
            date = `0${appointmentDate.getDate()}`;
        }
        const appointmentObject = {
            "patientId": Number(sessionStorage.getItem(usersId)),
            "doctorId": Number(selectedDoctor[0].usersId),
            "appointmentDate": `${appointmentDate.getFullYear()}-${appointmentDate.getMonth() + 1}-${date}`,
            "appointmentTime": `${appointmentTime}:00`,
            "patientsNotes": patientsNotes
        }
        console.log(appointmentDate);
        axios.post(addAppointmentURL, appointmentObject).then((response) => {
            if (response.data.status) {
                // const appointmentId = response.data.data.appointmentId;
                setAppointment(prevValues => [...prevValues, response.data.data])
                // updateAppointmentTable(appointmentId)
            }
        })
        const updateAppointmentTable = (appointmentId) => {
            axios.get(`${getAppointmentById}/${appointmentId}`).then((response) => {
                if (response.data.status) {
                    setAppointment(prevValues => [...prevValues, response.data.data])
                }
            })
        }

        console.log("object: ", appointmentObject);
        console.log("date: ", Number(`0${appointmentDate.getDate()}`));
    }
    return (
        <>
            <div className="auth-form-light text-left py-5 px-4 px-sm-5">
                <i className="mdi mdi-window-close float-right" onClick={toggleBookAppointmentModal}></i>
                <div className="brand-logo">
                    <img className='w-25 h-25' src={require("../../assets/images/logo.svg")} alt="logo" />
                </div>
                <h4>Book your appointment with our<div className='text-primary'>Specialized Doctors </div></h4>
                <form className="pt-3" onSubmit={bookAppointment}>
                    <div className='row'>
                        <Dropdown onSelect={specializationSelected}>
                            <Dropdown.Toggle variant="btn btn-outline-info px-3 mx-4" id="dropdownMenuOutlineButton1">
                                Select Specialization
                            </Dropdown.Toggle>
                            <Dropdown.Menu>
                                <Dropdown.Item eventKey={0}>Specialization</Dropdown.Item>
                                {specializations.map((specialization) =>
                                    <Dropdown.Item eventKey={`${specialization.specializationId}`}>{specialization.category}</Dropdown.Item>
                                )}
                            </Dropdown.Menu>
                        </Dropdown>
                        {isSpecializationSelected && doctors.length > 0 ?
                            <Dropdown onSelect={doctorSelected}>
                                <Dropdown.Toggle variant="btn btn-outline-info px-4 ml-2" id="dropdownMenuOutlineButton1">
                                    Select Doctor
                                </Dropdown.Toggle>
                                <Dropdown.Menu>
                                    {doctors.map((doctor) =>
                                        <Dropdown.Item eventKey={doctor.usersId}>
                                            {doctor.firstname} {doctor.lastname}
                                        </Dropdown.Item>
                                    )}
                                </Dropdown.Menu>
                            </Dropdown> : ""}
                    </div>
                    <div className='row ml-2 mt-2'>
                        {isSpecializationSelected && doctors.length > 0 ?
                            <h6 className="font-weight-light mr-5">{selectedSpecialization[0].category}</h6>
                            : ""}
                        {isDoctorSelected ?
                            <h7 className="font-weight-light float-right ml-auto mr-4">{selectedDoctor[0].firstname} {selectedDoctor[0].lastname}</h7>
                            : ""}
                    </div>
                    {isDoctorSelected ?
                        <div className='row mb-0 py-0'>
                            <Form.Group className="row">
                                <ReactDatePicker className="form-control w-75 mx-3 mt-3"
                                    selected={appointmentDate}
                                    onChange={handleAppointmentDateChange}
                                    minDate={new Date()}
                                    format='yyyy-MM-dd'
                                    maxDate={new Date() + 15}
                                    disabledDays={[new Date(2022, 12, 7)]}
                                />
                            </Form.Group>
                            <Form.Group>
                                <Dropdown onSelect={handleTimeChange}>
                                    <Dropdown.Toggle variant="btn btn-outline-info mt-3 ml-3" id="dropdownMenuOutlineButton1">
                                        Select Time
                                    </Dropdown.Toggle>
                                    <Dropdown.Menu>
                                        <Dropdown.Item eventkey="12:00">12:00</Dropdown.Item>
                                        <Dropdown.Item eventkey="13:00">13:00</Dropdown.Item>
                                        <Dropdown.Item eventkey="14:00">14:00</Dropdown.Item>
                                    </Dropdown.Menu>
                                </Dropdown>
                            </Form.Group>
                        </div>
                        : ""}
                    <div className='row mx-2 pt-0'>
                        {isDoctorSelected ?
                            <>
                                <h6 className="font-weight-light mr-4 ml-2 w-75"><Moment format='DD-MMM-YYYY' >{appointmentDate}</Moment></h6>
                                <h6 className="font-weight-light ml-auto mr-4">{appointmentTime}</h6>

                            </>
                            : ""}

                    </div>
                    {isDoctorSelected &&
                        <Form.Group className="d-flex search-field">
                            <Form.Control type="text" name="patientsNotes" onChange={handlePatienstNotesChange}
                                value={patientsNotes} placeholder="Message for doctor" size="lg" className="h-auto" />
                        </Form.Group>}
                    <div className="mt-3">
                        <button type='submit' className="btn btn-block btn-info btn-lg font-weight-medium auth-form-btn"
                            disabled={isSpecializationSelected && isDoctorSelected ? false : true}
                        >

                            Confirm Appointment
                        </button>
                    </div>

                </form>
            </div></>
    )
}

export default BookAppointmentModal