import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Dropdown, Modal } from 'react-bootstrap';
import Moment from 'react-moment';
import { allAppointmentStatus, appointmentStatus, getAllAppointmentsForAdmin, getAppointmentById, login, updateAppointment, usersId, usersRoleId } from '../utils/AllAPIS';

export const BasicTable = () => {
  const [specificAppointment, setSpecificAppointment] = useState({})
  const [isTextShown, setIsTextShown] = useState(false)
  const [description, setDescription] = useState('')
  const [heading, setHeading] = useState('')
  const [appointments, setAppointment] = useState([])
  const [isUserLoggedIn, setIsUserLoggedIn] = useState(false)
  const [userId, setUserId] = useState(0)
  const [userRole, setUserRole] = useState(0)
  const [text, setText] = useState('')

  const [{ descriptionText, feedback }, updateTextInputFields] =
    useState({ descriptionText: "", feedback: "" })

  useEffect(() => {
    setIsUserLoggedIn(sessionStorage.getItem(login))
    if (sessionStorage.getItem(login)) {
      setUserId(sessionStorage.getItem(usersId))
      setUserRole(sessionStorage.getItem(usersRoleId))
      // axios.get()
      axios.get(getAllAppointmentsForAdmin).then((response) => {
        if (response.data.status && response.data.data) {
          setAppointment(response.data.data)
        } else {
          alert(response.data.message)
        }
      })
    } else {
      // navigate to dashboard
    }
  }, [])

  const handleTextChange = (event) => {
    const { name, value } = event.target;
    console.log(`name: ${name} value: ${value} `);
    updateTextInputFields((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  }
  const showModalText = (appointment, heading, text) => {
    console.log("appointment: ", appointment);
    setSpecificAppointment(appointment)
    setIsTextShown(true)
    setHeading(heading)
    setText(text)
  }
  const hideModal = () => {
    setIsTextShown(!isTextShown)
  }

  const handleAppointmentStatusChange = (eventKey) => {
    axios.get(`${getAppointmentById}/${Number(eventKey.split("##")[1])}`).then((response) => {
      if (response.data.status) {
        const appointment = response.data.data;
        appointment.appointmentStatus = eventKey.split("##")[0];
        updateAppointments(appointment)
      }
    })
  }
  const updateAppointments = (appointment) => {
    console.log("app: ", appointment);
    axios.put(`${updateAppointment}/${appointment.appointmentId}`,
      appointment).then((response) => {
        if (response.data.status) {
          console.log(response.data.data);
        } alert(response.data.message)
      })
  }
  const appointmentStatusBadge = (status) => {
    if (status === allAppointmentStatus.PENDING)
      return (<label className="badge badge-danger">{status}</label>)
    else if (status === allAppointmentStatus.COMPLETED)
      return (<label className="badge badge-success">{status}</label>)
    else if (status === allAppointmentStatus.CANCELED)
      return (<label className="badge badge-danger">{status}</label>)
    else if (status === allAppointmentStatus.APPROVE)
      return (<label className="badge badge-warning">{status}</label>)
    else if (status === allAppointmentStatus.CANCELED || status === allAppointmentStatus.REJECTED)
      return (<label className="badge badge-danger">{status}</label>)
  }

  return (
    <div>
      <div className="page-header">
        <h3 className="page-title">Manage Appointments </h3>
        <nav aria-label="breadcrumb">
          <ol className="breadcrumb">
            <li className="breadcrumb-item mr-0">

            </li>
          </ol>
        </nav>
      </div>
      <div className="row">
        <div className="col-lg-12 grid-margin stretch-card">
          <div className="card">
            <div className="card-body">
              <p className="card-description">
              </p>
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th className='text-center'>Patient's Name</th>
                      <th className='text-center'>Email</th>
                      <th className='text-center'>Doctor's Name</th>
                      <th className='text-center'>Email</th>
                      <th className='text-center'>Date</th>
                      <th className='text-center'>Time</th>
                      <th className='text-center'>Status</th>
                      <th className='text-center'>Change</th>
                      <th className='text-center'>Feedback</th>
                      <th className='text-center'>Prescription</th>
                      <th className='text-center'>Notes</th>
                      <th className='text-center'>Created</th>
                    </tr>
                  </thead>
                  <tbody>
                    {appointments && appointments.map((appointment, index) =>
                      <tr>
                        <td className='text-center'>{index + 1}</td>
                        <td className='text-center'>{`${appointment.patientsFirstname} ${appointment.patientsLastname}`}</td>
                        <td className='text-center'>{appointment.email}</td>
                        <td className='text-center'>{`${appointment.doctorsFirstname} ${appointment.doctorsLastname}`}</td>
                        <td className='text-center'>{appointment.doctorsEmail}</td>
                        <td className='text-center'>{appointment.appointmentDate}</td>
                        <td className='text-center'>{appointment.appointmentTime}</td>
                        <td className='text-center'>{appointmentStatusBadge(appointment.appointmentStatus)}
                        </td>
                        <td className='text-center'>
                          <Dropdown onSelect={handleAppointmentStatusChange}>
                            <Dropdown.Toggle variant="btn btn-primary btn-sm" id="dropdownMenuSizeButton3">
                              Change
                            </Dropdown.Toggle>
                            <Dropdown.Menu>
                              {appointmentStatus.map((appointmentStatus) =>
                                <Dropdown.Item eventKey={`${appointmentStatus}##${appointment.appointmentId}`}>{appointmentStatus}</Dropdown.Item>
                              )}
                            </Dropdown.Menu>
                          </Dropdown>
                        </td>
                        <td className='text-center'>
                          <button disabled={appointment.appointmentStatus !== "COMPLETED" || appointment.feedback === null ? true : false}
                            onClick={() => showModalText(appointment, "Feedback", appointment.feedback)}>
                            {appointment.feedback != null ? "View" : "None"}
                          </button>
                        </td>
                        <td className='text-center'>
                          <button disabled={appointment.appointmentStatus !== "PENDING" ? false : true}
                            onClick={() => showModalText(appointment, "Prescription", appointment.prescription)}>
                            {appointment.prescription !== null ? "View" : "None"}
                          </button>
                        </td>
                        <td className='text-center'>
                          <button disabled={appointment.patientsNotes == null ? true : false}
                            onClick={() => showModalText(appointment, "Notes", appointment.patientsNotes)}>
                            {appointment.patientsNotes != null ? "View" : "None"}
                          </button>
                        </td>
                        <td className='text-center'><Moment format='DD-MM-YYYY HH:mm' >{appointment.createdTime}</Moment>
                        </td>
                      </tr>)
                    }
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
      <Modal show={isTextShown}>
        <div className="auth-form-light text-left py-5 px-4 px-sm-5">
          <i className="mdi mdi-close float-right" onClick={hideModal}></i>
          <div className="brand-logo">
            <img className='w-25 h-25' src={require("../../assets/images/logo.svg")} alt="logo" />
          </div>
          <h4>{heading}</h4>
          <h3 className="font-weight-light">{text}</h3>
        </div>
      </Modal>

    </div>
  )

}

export default BasicTable;
