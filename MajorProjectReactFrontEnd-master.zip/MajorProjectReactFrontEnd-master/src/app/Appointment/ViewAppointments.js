import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Form, Modal } from 'react-bootstrap';
import Moment from 'react-moment';
import { addPrescription, allAppointmentStatus, getAllAppointmentsForDoctor, getAllAppointmentsForPatient, login, updateAppointment, usersId, usersRoleId } from '../utils/AllAPIS';
import BookAppointmentModal from './BookAppointmentModal';

export const BasicTable = () => {
  const [specificAppointment, setSpecificAppointment] = useState({})
  const [isTextShown, setIsTextShown] = useState(false)
  const [description, setDescription] = useState('')
  const [heading, setHeading] = useState('')
  const [appointments, setAppointment] = useState([])
  const [isUserLoggedIn, setIsUserLoggedIn] = useState(false)
  const [userId, setUserId] = useState(0)
  const [userRole, setUserRole] = useState(0)
  const [text, setText] = useState('')
  const [isBookAppointmentModalShown, setIsBookAppointmentModalShown] = useState(false)

  const [{ descriptionText, feedback }, updateTextInputFields] =
    useState({ descriptionText: "", feedback: "" })

  useEffect(() => {
    setIsUserLoggedIn(sessionStorage.getItem(login))
    if (sessionStorage.getItem(login)) {
      setUserId(sessionStorage.getItem(usersId))
      setUserRole(sessionStorage.getItem(usersRoleId))
      let appointmentUrl;
      if (Number(sessionStorage.getItem(usersRoleId)) === 2) {
        appointmentUrl = `${getAllAppointmentsForDoctor}/${sessionStorage.getItem(usersId)}`
      } else {
        appointmentUrl = `${getAllAppointmentsForPatient}/${sessionStorage.getItem(usersId)}`
      }
      axios.get(appointmentUrl).then((response) => {
        if (response.data.status && response.data.data) {
          setAppointment(response.data.data)
        } else {
          alert(response.data.message)
        }
      })
    } else {

    }
  }, [])

  const handleTextChange = (event) => {
    const { name, value } = event.target;
    console.log(`name: ${name} value: ${value} `);
    updateTextInputFields((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  }
  const showModalText = (appointment, heading, text) => {
    console.log("appointment: ", appointment);
    setSpecificAppointment(appointment)
    setIsTextShown(true)
    setHeading(heading)
    setText(text)
  }
  const hideModal = () => {
    setIsTextShown(!isTextShown)
  }

  const addDescriptionText = (event) => {

    event.preventDefault();
    if (heading === "Prescription") {
      const updatedAppointment = {
        "patientId": specificAppointment.patientId,
        "doctorId": specificAppointment.doctorId,
        "appointmentDate": specificAppointment.appointmentDate,
        "appointmentTime": specificAppointment.appointmentTime,
        "prescription": descriptionText,
        "patientsNotes": specificAppointment.patientsNotes,
        "appointmentStatus": specificAppointment.appointmentStatus,
        "doctorsRatings": specificAppointment.doctorsRatings,
        "feedback": specificAppointment.feedback,
        "createdTime": specificAppointment.createdTime
      }
      axios.put(`${addPrescription}/${specificAppointment.appointmentId}`,
        updatedAppointment).then((response) => {
          if (response.data.status) {
            console.log(response.data.data);
          } alert(response.data.message)
        })

    } else if (heading === "Feedback") {
      console.log("this is feedback");
      const updatedAppointment = {
        "patientId": specificAppointment.patientId,
        "doctorId": specificAppointment.doctorId,
        "appointmentDate": specificAppointment.appointmentDate,
        "appointmentTime": specificAppointment.appointmentTime,
        "prescription": specificAppointment.prescription,
        "patientsNotes": specificAppointment.patientsNotes,
        "appointmentStatus": specificAppointment.appointmentStatus,
        "doctorsRatings": specificAppointment.doctorsRatings,
        "feedback": descriptionText,
        "createdTime": specificAppointment.createdTime
      }
      axios.put(`${updateAppointment}/${specificAppointment.appointmentId}`,
        updatedAppointment).then((response) => {
          if (response.data.status) {
            console.log(response.data.data);
          } alert(response.data.message)
        })
    }
    // feedback for the doctor ray hold for appointment on 2022-12-15 from swaraj motiwale

  }
  const toggleBookAppointmentModal = (event) => {
    event.preventDefault()
    setIsBookAppointmentModalShown(!isBookAppointmentModalShown)
  }
  const appointmentStatusBadge = (status) => {
    if (status === allAppointmentStatus.PENDING)
      return (<label className="badge badge-danger">{status}</label>)
    else if (status === allAppointmentStatus.COMPLETED)
      return (<label className="badge badge-success">{status}</label>)
    else if (status === allAppointmentStatus.CANCELED)
      return (<label className="badge badge-danger">{status}</label>)
    else if (status === allAppointmentStatus.APPROVE)
      return (<label className="badge badge-warning">{status}</label>)
    else if (status === allAppointmentStatus.CANCELED || status === allAppointmentStatus.REJECTED)
      return (<label className="badge badge-danger">{status}</label>)
  }
  return (
    <div>
      <div className="page-header">
        <h3 className="page-title">Your Appointments </h3>
        <nav aria-label="breadcrumb">
          <ol className="breadcrumb">
            <li className="breadcrumb-item mr-0">
              {Number(userRole) === 3 &&
                <button className='btn btn-info px-2 py-2' onClick={toggleBookAppointmentModal}>
                  Book Appointment
                </button>}

            </li>
          </ol>
        </nav>
      </div>
      <div className="row">
        <div className="col-lg-12 grid-margin stretch-card">
          <div className="card">
            <div className="card-body">
              <p className="card-description">
              </p>
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>#</th>
                      {Number(userRole) === 2 ? <>
                        <th>Patient's Name</th>
                        <th>Email</th></> : ""}
                      {Number(userRole) === 3 ? <>
                        <th>Doctor's Name</th>
                        <th>Email</th>
                      </> : ""}
                      <th>Date</th>
                      <th>Time</th>
                      <th>Status</th>
                      <th>Feedback</th>
                      <th>Prescription</th>
                      <th>Notes</th>
                      <th>Created</th>
                    </tr>
                  </thead>
                  <tbody>
                    {appointments && appointments.map((appointment, index) =>
                      <tr>
                        <td className='text-center'>{index + 1}</td>
                        {Number(userRole) === 2 ?
                          <>
                            <td className='text-center'>{`${appointment.patientsFirstname} ${appointment.patientsLastname}`}</td>
                            <td className='text-center'>{appointment.email}</td>
                          </> : ""}
                        {Number(userRole) === 3 ? <>
                          <td className='text-center'>{`${appointment.doctorsFirstname} ${appointment.doctorsLastname}`}</td>
                          <td className='text-center'>{appointment.doctorsEmail}</td>
                        </> : ""}
                        <td className='text-center'>{appointment.appointmentDate}</td>
                        <td className='text-center'>{appointment.appointmentTime}</td>
                        <td className='text-center'>{appointmentStatusBadge(appointment.appointmentStatus)}
                        </td>
                        <td className='text-center'>
                          <button disabled={(appointment.appointmentStatus !== "COMPLETED" || appointment.feedback === null) ? true : false}
                            onClick={() => showModalText(appointment, "Feedback", appointment.feedback)}>
                            {(Number(sessionStorage.getItem(usersRoleId)) === 3 && appointment.feedback == null) ? "Add" : "View"}
                          </button>
                        </td>
                        <td className='text-center'>
                          <button disabled={appointment.appointmentStatus === "PENDING" ? true : false}
                            onClick={() => showModalText(appointment, "Prescription", appointment.prescription)}>
                            {(Number(sessionStorage.getItem(usersRoleId)) === 2 && appointment.prescription === null) ? "Add" : "View"}
                          </button>
                        </td>
                        <td className='text-center'>
                          <button disabled={appointment.patientsNotes == null ? true : false}
                            onClick={() => showModalText(appointment, "Notes", appointment.patientsNotes)}>
                            {appointment.patientsNotes != null ? "View" : "No Notes"}
                          </button>
                        </td>
                        <td className='text-center'><Moment format='DD-MM-YYYY HH:mm' >{appointment.createdTime}</Moment>
                        </td>
                      </tr>)
                    }
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
      <Modal show={isTextShown}>
        <div className="auth-form-light text-left py-5 px-4 px-sm-5">
          <i className="mdi mdi-close float-right" onClick={hideModal}></i>
          <div className="brand-logo">
            <img className='w-25 h-25' src={require("../../assets/images/logo.svg")} alt="logo" />
          </div>
          <h4>{heading}</h4>

          {text === null ?
            <form className="pt-3" onSubmit={addDescriptionText}>
              <Form.Group className="d-flex search-field">
                <Form.Control type="text" name="descriptionText" value={descriptionText} onChange={handleTextChange}
                  placeholder={`Write ${heading}`} size="lg" className="h-auto" />
              </Form.Group>
              <div className="mt-3">
                <button type='submit' className="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn">
                  ADD {heading.toUpperCase()}
                </button>
              </div>
            </form> :
            <h3 className="font-weight-light">{text}</h3>
          }
        </div>
      </Modal>
      <Modal show={isBookAppointmentModalShown}>
        <BookAppointmentModal
          toggleBookAppointmentModal={toggleBookAppointmentModal}
          appointments={setAppointment}

        />
      </Modal>
    </div>
  )
}
export default BasicTable;


