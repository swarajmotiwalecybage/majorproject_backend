import axios from 'axios';
import React, { useEffect, useState } from 'react';
import Moment from 'react-moment';
import { getAllUsers } from '../utils/AllAPIS';

export const BasicTable = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    axios.get(getAllUsers).then((response) => {
      if (response.data.status) {
        setUsers(response.data.data)
      } else {
        alert(response.data.message)
      }
    })
  }, [])
  const accountStatus = status => {
    if (status === 1) {
      return (<label className="badge badge-success">Active</label>)
    } else if (status === 2) {
      return (<label className="badge badge-warning">Inactive</label>)
    } else if (status === 3) {
      return (<label className="badge badge-danger">Blocked</label>)
    } else if (status === 4) {
      return (<label className="badge badge-danger">Blocked By Admin</label>)
    } else if (status === 5) {
      return (<label className="badge badge-danger">Deleted</label>)
    }

  }
  return (
    <div>
      <div className="page-header">
        <h3 className="page-title"> All Users</h3>

      </div>
      <div className="row">
        <div className="col-lg-12 grid-margin stretch-card">
          <div className="card">
            <div className="card-body">
              <h4 className="card-title">Patient List</h4>
              <p className="card-description">
              </p>
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Mobile</th>
                      <th>Status</th>
                      <th>Account Created</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users && users.map((user, index) =>
                      <tr>
                        <td>{index + 1}</td>
                        <td>{user.firstname} {user.lastname}</td>
                        <td>{user.email}</td>
                        <td>{user.mobile}</td>
                        <td>{accountStatus(user.accountStatus)}</td>
                        <td>
                          <Moment format='DD-MM-YYYY HH:mm:SS' >{user.accountCreated}</Moment>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )

}

export default BasicTable;
