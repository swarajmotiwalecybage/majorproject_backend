import axios from 'axios';
import React from 'react'
import { useState } from 'react';
import { useEffect } from 'react';
import { Dropdown } from 'react-bootstrap';
import Moment from 'react-moment';
import { getAllDoctors } from '../utils/AllAPIS';

export const BasicTable = () => {

  const [doctors, setDoctors] = useState([]);
  useEffect(() => {
    axios.get(getAllDoctors).then((response) => {
      if (response.data.status && response.data.data) {
        setDoctors(response.data.data)
      } else {
        alert(response.data.message)
      }
    })
  }, [])
  return (
    <div>
      <div className="page-header">
        <h3 className="page-title"> Doctors tables</h3>
        <nav aria-label="breadcrumb">
          <ol className="breadcrumb">
            <li className="breadcrumb-item"><a href="!#" onClick={event => event.preventDefault()}>Tables</a></li>
            <li className="breadcrumb-item active" aria-current="page">Doctors tables</li>
          </ol>
        </nav>
      </div>
      <div className="row">
        <div className="col-lg-12 grid-margin stretch-card">
          <div className="card">
            <div className="card-body">
              <h4 className="card-title">Doctor List</h4>
              <p className="card-description">
              </p>
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Mobile</th>
                      <th>Specializations</th>
                      <th>Status</th>
                      <th>Account Created</th>
                    </tr>
                  </thead>
                  <tbody>
                    {doctors && doctors.map((doctor, index) =>
                      <tr>
                        <td>{index + 1}</td>
                        <td>{doctor.firstname} {doctor.lastname}</td>
                        <td>{doctor.email}</td>
                        <td>{doctor.mobile}</td>
                        <td>
                          <Dropdown>
                            <Dropdown.Toggle className='sm' variant="btn btn-outline-primary " id="dropdownMenuOutlineButton1">
                              Specializations
                            </Dropdown.Toggle>
                            <Dropdown.Menu>
                              {doctor.specializations.map((specialization) =>
                                <Dropdown.Item>{specialization.category}</Dropdown.Item>
                              )}
                            </Dropdown.Menu>
                          </Dropdown>

                        </td>
                        <td>{doctor.accountStatus === 1 ?
                          <label className="badge badge-success">Active</label> :
                          <label className="badge badge-warning">Inactive</label>}
                        </td>
                        <td>
                          <Moment format='DD-MM-YYYY HH:mm' >{doctor.accountCreated}</Moment>
                        </td>
                      </tr>

                    )} </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  )
}

export default BasicTable
