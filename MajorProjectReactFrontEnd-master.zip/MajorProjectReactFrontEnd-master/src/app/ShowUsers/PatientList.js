import axios from 'axios';
import React, { useEffect, useState } from 'react';
import Moment from 'react-moment';
import { getAllPatients } from '../utils/AllAPIS';

export const BasicTable = () => {
  const [patients, setPatients] = useState([]);
  const [allPatients, setAllPatients] = useState([]);

  const [{ search }, updateSearchFields] =
    useState({ search: "" })
  useEffect(() => {
    axios.get(getAllPatients).then((response) => {
      if (response.data.status) {
        setPatients(response.data.data)
        setAllPatients(response.data.data)
      } else {
        alert(response.data.message)
      }
    })
  }, [])



  const searchByEmail = (event) => {
    console.log("empty serch field");
    if (event.target.value.trim().length === 0) {
      console.log("empty serch fieldddd");
      setPatients(allPatients);
    }
    const { name, value } = event.target;
    updateSearchFields((prevState) => ({
      ...prevState,
      [name]: value,
    }));
    
    if (search.trim().length !== 0) {
      const seachPatientByName = patients.filter((patient) =>
        `${patient.firstname}`.toLowerCase().includes(search))
      setPatients(seachPatientByName)
    } else if (patients.length !== 0) {
      console.log("else part")
      setPatients(allPatients);
    }
    console.log(`event: ${event.target.value}`);
    console.log(patients.filter((patient) =>
      patient.firstname.includes(search)));
  }
  return (
    <div>
      <div className="page-header">
        <h3 className="page-title"> All Patients </h3><br></br>
        <nav aria-label="breadcrumb">
          <ol className="breadcrumb">
            <li className="breadcrumb-item active" aria-current="page">
              <form>
                <div className="search-field d-none d-md-block">
                  <form className="d-flex align-items-center h-100" action="#">
                    <div className="input-group">
                      <div className="input-group-prepend bg-transparent">
                        <i className="input-group-text border-0 mdi mdi-magnify"></i>
                      </div>
                      <input onChange={searchByEmail} value={search} type="text" name='search' className="form-control border-1 col-md-6" placeholder="Search Name" />
                      <input type="text" className="form-control border-1 col-md-6" placeholder="Search Email" />
                    </div>
                  </form>
                </div>
              </form>
            </li>
          </ol>
        </nav>
      </div>
      <div className="row">

        <div className="col-lg-12 grid-margin stretch-card">
          <div className="card">
            <div className="card-body">
              <h4 className="card-title">Patients</h4>
              <p className="card-description">
              </p>
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Mobile</th>
                      <th>Status</th>
                      <th>Account Created</th>
                    </tr>
                  </thead>
                  <tbody>
                    {patients && patients.map((patient, index) =>
                      <tr>
                        <td>{index + 1}</td>
                        <td>{patient.firstname} {patient.lastname}</td>
                        <td>{patient.email}</td>
                        <td>{patient.mobile}</td>
                        <td>{patient.accountStatus === 1 ?
                          <label className="badge badge-success">Active</label> :
                          <label className="badge badge-warning">Inactive</label>}
                        </td>
                        <td>
                          <Moment format='DD-MM-YYYY HH:mm:SS' >{patient.accountCreated}</Moment>
                        </td>
                      </tr>

                    )}

                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  )
}

export default BasicTable



/*
else if({patient.accountStatus} === 3)
                          <label className="badge badge-danger">Blocked</label>
                        else if({patient.accountStatus} ==== 4)
                          <label className="badge badge-danger">Blocked By Admin</label>
                        else if({patient.accountStatus} ==== 5)
                          <label className="badge badge-danger">Deleted</label>)
*/