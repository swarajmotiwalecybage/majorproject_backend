import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Dropdown } from 'react-bootstrap';
import Moment from 'react-moment';
import { getAllUsers, login, usersAccountStatus } from '../utils/AllAPIS';

export const BasicTable = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    if (sessionStorage.getItem(login)) {
    axios.get(getAllUsers).then((response) => {
      if (response.data.status) {
        setUsers(response.data.data)
      } else {
        alert(response.data.message)
      }
    })}
  }, [])
  const handleUsersStatusChange = (eventKey) => {
    console.log(`new status selected: ${eventKey}`);
    // axios.get(`${getAppointmentById}/${Number(eventKey.split("##")[1])}`).then((response) =>{
    //   if(response.data.status){
    //     const appointment = response.data.data;
    //     appointment.appointmentStatus=eventKey.split("##")[0];
    //     updateAppointments(appointment)
    //   }
    // })
  }
  const accountStatus = status => {
    if (status === 1) {
      return (<label className="badge badge-success">Active</label>)
    } else if (status === 2) {
      return (<label className="badge badge-warning">Inactive</label>)
    } else if (status === 3) {
      return (<label className="badge badge-danger">Blocked</label>)
    } else if (status === 4) {
      return (<label className="badge badge-danger">Blocked By Admin</label>)
    } else if (status === 5) {
      return (<label className="badge badge-danger">Deleted</label>)
    }
  }
  const  updateStatus=(status, user)=>{
    console.log(status);
    console.log(user);
  }
  return (
    <div>
      <div className="page-header">
        <h3 className="page-title"> Unblock User</h3>
        <nav aria-label="breadcrumb">
          <ol className="breadcrumb">
            <li className="breadcrumb-item"><a href="!#" onClick={event => event.preventDefault()}>Tables</a></li>
            <li className="breadcrumb-item active" aria-current="page">UnblockUser tables</li>
          </ol>
        </nav>
      </div>
      <div className="row">

        <div className="col-lg-12 grid-margin stretch-card">
          <div className="card">
            <div className="card-body">
              <h4 className="card-title">Patient List</h4>
              <p className="card-description">
              </p>
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th className='text-center'>#</th>
                      <th className='text-center'>Name</th>
                      <th className='text-center'>Email</th>
                      <th className='text-center'>Mobile</th>
                      <th className='text-center'>Status</th>
                      <th className='text-center'>Change</th>
                      <th className='text-center'>Account Created</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users && users.map((user, index) =>
                      <tr>
                        <td className='text-center'>{index + 1}</td>
                        <td className='text-center'>{user.firstname} {user.lastname}</td>
                        <td className='text-center'>{user.email}</td>
                        <td className='text-center'>{user.mobile}</td>
                        <td className='text-center'>{accountStatus(user.accountStatus)}</td>
                          <td className='justify-content align-center'>
                            <Dropdown onSelect={handleUsersStatusChange}>
                              <Dropdown.Toggle variant="btn btn-primary btn-sm" id="dropdownMenuSizeButton3">
                                Change
                              </Dropdown.Toggle>
                              <Dropdown.Menu>
                                {usersAccountStatus.map((status) =>
                                  // <Dropdown.Item onClick={(user) =>updateStatus(user, status)} eventKey={status}>{status}</Dropdown.Item>
                                  <Dropdown.Item eventKey={status}>{status}</Dropdown.Item>
                                )}
                              </Dropdown.Menu>
                            </Dropdown>
                          </td>
                        <td className='text-center'>
                          <Moment format='DD-MM-YYYY HH:mm:SS' >{user.accountCreated}</Moment>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  )
}
export default BasicTable