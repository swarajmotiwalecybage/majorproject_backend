import React, { Component } from 'react'

export class BlankPage extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}

export default BlankPage
