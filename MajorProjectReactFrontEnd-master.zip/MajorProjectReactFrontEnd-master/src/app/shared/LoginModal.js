import axios from 'axios';
import React from 'react'
import { useState } from 'react';
import { Form } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { login, sendLoginOTP, usersFirstname, usersId, usersRoleId, verifyLoginOTP } from '../utils/AllAPIS';

const LoginModal = ({ dontHaveAnAccount, isOTPSent, setIsOTPSent, initModalLogin }) => {
    const [{ loginEmail, otp }, updateLoginInputFields] =
        useState({ loginEmail: "", otp: "" })
    const handleLoginChange = (event) => {
        const { name, value } = event.target;
        updateLoginInputFields((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    }
    const editEmail = () => {
        setIsOTPSent(false)
    }
    const sendOtp = (event) => {
        event.preventDefault();
        if (!isOTPSent) {

            axios.get(`${sendLoginOTP}/${loginEmail}`).then((response) => {
                if (response.data.status) {
                    setIsOTPSent(true)
                } else {
                }
                alert(response.data.message)
            })
        } else {
            axios.get(`${verifyLoginOTP}/${loginEmail}/${otp.toString()}`).then((response) => {
                if (response.data.status) {
                    sessionStorage.setItem(usersId, response.data.data.usersId)
                    sessionStorage.setItem(usersRoleId, response.data.data.usersRoleId)
                    sessionStorage.setItem(usersFirstname, response.data.data.firstname)
                    sessionStorage.setItem(login, true)
                    window.location.reload();
                } else {
                    alert(response.data.message)
                }
            })
        }

    }
    return (
        <>
            <div className="auth-form-light text-left py-5 px-4 px-sm-5">
                <i className="mdi mdi-close float-lg-right" onClick={initModalLogin}></i>
                <div className="brand-logo">
                    <img className='w-25 h-25' src={require("../../assets/images/logo.svg")} alt="logo" />
                </div>
                <h4>Hello! let's get started</h4>
                <h6 className="font-weight-light">Sign in to continue.</h6>
                <form className="pt-3" onSubmit={sendOtp}>
                    <Form.Group className="d-flex search-field">
                        <Form.Control type="email" disabled={isOTPSent} name="loginEmail" onChange={handleLoginChange} value={loginEmail} placeholder="Email" size="lg" className="h-auto" />
                    </Form.Group>
                    {isOTPSent ?
                        <Form.Group className="d-flex search-field">
                            <Form.Control type="number" name="otp" placeholder="OTP(******)" onChange={handleLoginChange} value={otp} size="lg" className="h-auto" />
                        </Form.Group>
                        : ""}
                    <div className="mt-3">
                        {isOTPSent ? <button type='submit' disabled={otp.length !== 6 ? true : false}
                         className="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" to="/dashboard">
                            SIGN IN
                        </button>:
                        <button type='submit'
                         className="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" to="/dashboard">
                            SEND OTP
                        </button>}
                    </div>
                    <div className="my-2 d-flex justify-content-between align-items-center">
                        {isOTPSent &&
                            <a href="#" onClick={editEmail} className="auth-link text-black">Edit email?</a>
                        }
                    </div>
                    <div className="text-center mt-4 font-weight-light">
                        Don't have an account? <Link onClick={dontHaveAnAccount} className="text-primary">Create</Link>
                    </div>
                </form>
            </div></>
    )
}

export default LoginModal