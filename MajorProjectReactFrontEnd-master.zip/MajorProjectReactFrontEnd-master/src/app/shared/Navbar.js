import React from 'react';
import { Dropdown, Form, Modal } from 'react-bootstrap';
import { Link } from 'react-router-dom';
// import { useNavigate } from "react-router-dom";
import { Trans } from 'react-i18next';
import { useState } from 'react';
import axios from 'axios';
import { login, registerPatientURL, usersFirstname } from '../utils/AllAPIS';
import LoginModal from './LoginModal';
import { useEffect } from 'react';

export const Navbar = () => {
  // const navigate = useNavigate();
  const [isUserLoggedIn, setIsUserLoggedIn] = useState(false)
  const [isShowRegister, invokeModalRegister] = useState(false)
  const [isShowLogin, invokeModalLogin] = useState(false)
  const [isOTPSent, setIsOTPSent] = useState(false)
  const [{ firstname, lastname, email, mobile }, updateInputFields] =
    useState({ firstname: "", lastname: "", email: "", mobile: "" })

  useEffect(() => {
    setIsUserLoggedIn(sessionStorage.getItem(login))
  })




  const handleChange = (event) => {
    const { name, value } = event.target;
    console.log(`name: ${name} value: ${value} `);
    updateInputFields((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  }

  const initModalRegister = () => {
    return invokeModalRegister(!isShowRegister)
  }
  const initModalLogin = () => {
    setIsOTPSent(false)
    return invokeModalLogin(!isShowLogin)
  }
  const dontHaveAnAccount = () => {
    invokeModalLogin(false)
    return invokeModalRegister(true)
  }
  const alreadyHaveAnAccount = () => {
    setIsOTPSent(false)
    invokeModalRegister(false)
    return invokeModalLogin(true)
  }
  function toggleOffcanvas() {
    document.querySelector('.sidebar-offcanvas').classList.toggle('active');
  }
  function toggleRightSidebar() {
    document.querySelector('.right-sidebar').classList.toggle('open');
  }

  const handleSubmit = (event) => {
    event.preventDefault();
    const userObject = {
      "firstname": firstname,
      "lastname": lastname,
      "email": email,
      "usersProfileUrl": "some url",
      "mobile": mobile.toString(),
      "usersRoleId": 2
    }
    updateDatabase(userObject)
  }
  const updateDatabase = (object) => {
    axios.post(registerPatientURL, object).then((response) => {
      alert(response.data.message)
      alreadyHaveAnAccount()
    })
  }
  const signOutUser = () => {
    sessionStorage.clear()
    setIsUserLoggedIn(false)
    
    window.location.reload();
  }


  return (
    <nav className="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div className="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <Link className="navbar-brand brand-logo" to="/"><img src={require('../../assets/images/logo.svg')} alt="logo" /></Link>
        <Link className="navbar-brand brand-logo-mini" to="/"><img src={require('../../assets/images/logo-mini.svg')} alt="logo" /></Link>
      </div>
      <div className="navbar-menu-wrapper d-flex align-items-stretch">
        <button className="navbar-toggler navbar-toggler align-self-center" type="button" onClick={() => document.body.classList.toggle('sidebar-icon-only')}>
          <span className="mdi mdi-menu"></span>
        </button>
        <ul className="navbar-nav navbar-nav-right">
          <li className="nav-item nav-profile">
            <Dropdown alignRight>
              <Dropdown.Toggle className="nav-link">
                <div className="nav-profile-img">
                  {isUserLoggedIn ? <img src={require("../../assets/images/faces/face1.jpg")} alt="user" /> : ""}

                </div>
                {isUserLoggedIn ?
                  <div className="nav-profile-text">
                    <p className="mb-1 text-black"><Trans>{sessionStorage.getItem(usersFirstname)}</Trans></p>
                  </div> : <div className="nav-profile-text">
                    <p className="mb-1 text-black"><Trans>Login</Trans></p>
                  </div>}
              </Dropdown.Toggle>

              <Dropdown.Menu className="navbar-dropdown">

                {!isUserLoggedIn ?
                  <><Link to="">
                    <Dropdown.Item href="!#" onClick={evt => evt.preventDefault()}>
                      <i className="mdi mdi-cached mr-2 text-success"></i>
                      <Trans><a onClick={initModalLogin}>Login</a></Trans>
                    </Dropdown.Item></Link>
                    <Link to="">
                      <Dropdown.Item href="!#" onClick={evt => evt.preventDefault()}>
                        <i className="mdi mdi-logout mr-2 text-primary"></i>
                        <Trans> <a onClick={initModalRegister}> SignUp</a></Trans>
                      </Dropdown.Item></Link></>
                  : <>
                    <Link to="">
                      <Dropdown.Item href="!#" onClick={evt => evt.preventDefault()}>
                        <i className="mdi mdi-logout mr-2 text-primary"></i>
                        <Trans> <a onClick={signOutUser}>Signout</a></Trans>
                      </Dropdown.Item></Link>
                  </>
                }
              </Dropdown.Menu>
            </Dropdown>
          </li>
        </ul>
        <button className="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" onClick={toggleOffcanvas}>
          <span className="mdi mdi-menu"></span>
        </button>
      </div>
      <Modal show={isShowRegister}>
        <div className="auth-form-light text-left py-5 px-4 px-sm-5">
          <i className="mdi mdi-close float-lg-right" onClick={initModalRegister}></i>
          <div className="brand-logo">
            <img className='w-25 h-25' src={require("../../assets/images/logo.svg")} alt="logo" />
          </div>
          <h4>New here?</h4>
          <h6 className="font-weight-light">Signing up is easy. It only takes a few steps</h6>
          <form className="pt-3" onSubmit={handleSubmit}>
            <div className="form-group">
              <div className='row'>
                <input type="text" className="form-control col-sm-5 ml-4 form-control-lg"
                  id="exampleInputUsername1" name='firstname' onChange={handleChange} value={firstname} placeholder="Firstname" />
                <input type="text" className="form-control col-sm-5 ml-4 form-control-lg"
                  id="exampleInputUsername1" name='lastname' onChange={handleChange} value={lastname} placeholder="Lastname" />
              </div>
            </div>
            <div className="form-group">
              <input type="email" className="form-control form-control-lg"
                id="exampleInputEmail1" name='email' onChange={handleChange} value={email} placeholder="Email" />
            </div>
            <div className="form-group">
              <input type="number" className="form-control form-control-lg"
                id="exampleInputEmail1" name='mobile' onChange={handleChange} value={mobile} placeholder="Mobile" />
            </div>
            <div className="mt-3">
              <button className="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" type='submit'>SIGN UP</button>
            </div>
            <div className="text-center mt-4 font-weight-light">
              Already have an account? <Link onClick={alreadyHaveAnAccount} className="text-primary">Login</Link>
            </div>
          </form>
        </div>
      </Modal>
      <Modal show={isShowLogin}>
        <LoginModal
          dontHaveAnAccount={dontHaveAnAccount}
          isOTPSent={isOTPSent}
          setIsOTPSent={setIsOTPSent}
          initModalLogin={initModalLogin}
        />
      </Modal>
    </nav>

  );
}

export default Navbar;
