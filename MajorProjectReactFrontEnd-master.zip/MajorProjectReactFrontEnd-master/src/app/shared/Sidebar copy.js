import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';
import { Collapse } from 'react-bootstrap';
import { Trans } from 'react-i18next';

class SidebarCopy extends Component {

  state = {};

  toggleMenuState(menuState) {
    if (this.state[menuState]) {
      this.setState({ [menuState]: false });
    } else if (Object.keys(this.state).length === 0) {
      this.setState({ [menuState]: true });
    } else {
      Object.keys(this.state).forEach(i => {
        this.setState({ [i]: false });
      });
      this.setState({ [menuState]: true });
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.location !== prevProps.location) {
      this.onRouteChanged();
    }
  }

  onRouteChanged() {
    document.querySelector('#sidebar').classList.remove('active');
    Object.keys(this.state).forEach(i => {
      this.setState({ [i]: false });
    });

    const dropdownPaths = [
      { path: '/apps', state: 'appsMenuOpen' },
      { path: '/ShowUsers', state: 'ShowUsersMenuOpen' },
      { path: '/advanced-ui', state: 'advancedUiMenuOpen' },
      { path: '/Appointment', state: 'AppointmentMenuOpen' },
      { path: '/Complaints', state: 'ComplaintsMenuOpen' },
      { path: '/maps', state: 'mapsMenuOpen' },
      { path: '/UnblockUser', state: 'UnblockUserMenuOpen' },
      // { path: '/charts', state: 'chartsMenuOpen' },
      { path: '/user-pages', state: 'userPagesMenuOpen' },
      { path: '/error-pages', state: 'errorPagesMenuOpen' },
      { path: '/general-pages', state: 'generalPagesMenuOpen' },
      { path: '/ecommerce', state: 'ecommercePagesMenuOpen' },
    ];

    dropdownPaths.forEach((obj => {
      if (this.isPathActive(obj.path)) {
        this.setState({ [obj.state]: true })
      }
    }));

  }

  render() {
    return (
      <nav className="sidebar sidebar-offcanvas" id="sidebar">
        <ul className="nav">
          <li className="nav-item nav-profile">
            
          </li>
          <li className={this.isPathActive('/dashboard') ? 'nav-item active' : 'nav-item'}>
            <Link className="nav-link" to="/dashboard">
              <span className="menu-title"><Trans>Dashboard</Trans></span>
              <i className="mdi mdi-home menu-icon"></i>
            </Link>
          </li>
          <li className={this.isPathActive('/ShowUsers') ? 'nav-item active' : 'nav-item'}>
            <div className={this.state.ShowUsersMenuOpen ? 'nav-link menu-expanded' : 'nav-link'} onClick={() => this.toggleMenuState('ShowUsersMenuOpen')} data-toggle="collapse">
              <span className="menu-title"><Trans>Show Users</Trans></span>
              <i className="menu-arrow"></i>
              <i className="mdi mdi-crosshairs-gps menu-icon"></i>
            </div>
            <Collapse in={this.state.ShowUsersMenuOpen}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item"> <Link className={this.isPathActive('/ShowUsers/buttons') ? 'nav-link active' : 'nav-link'} to="/ShowUsers/buttons"><Trans>Buttons</Trans></Link></li>
                <li className="nav-item"> <Link className={this.isPathActive('/ShowUsers/dropdowns') ? 'nav-link active' : 'nav-link'} to="/ShowUsers/dropdowns"><Trans>Dropdowns</Trans></Link></li>
                <li className="nav-item"> <Link className={this.isPathActive('/ShowUsers/typography') ? 'nav-link active' : 'nav-link'} to="/ShowUsers/typography"><Trans>Typography</Trans></Link></li>
                <li className="nav-item"> <Link className={this.isPathActive('/ShowUsers/PatientList') ? 'nav-link active' : 'nav-link'} to="/ShowUsers/PatientList"><Trans>PatientList</Trans></Link></li>
                <li className="nav-item"> <Link className={this.isPathActive('/ShowUsers/DoctorsList') ? 'nav-link active' : 'nav-link'} to="/ShowUsers/DoctorsList"><Trans>DoctorsList</Trans></Link></li>
                <li className="nav-item"> <Link className={this.isPathActive('/ShowUsers/AllUsersList') ? 'nav-link active' : 'nav-link'} to="/ShowUsers/AllUsersList"><Trans>AllUsersList</Trans></Link></li>
              </ul>
            </Collapse>
          </li>
          <li className={this.isPathActive('/Appointment') ? 'nav-item active' : 'nav-item'}>
            <div className={this.state.AppointmentMenuOpen ? 'nav-link menu-expanded' : 'nav-link'} onClick={() => this.toggleMenuState('AppointmentMenuOpen')} data-toggle="collapse">
              <span className="menu-title"><Trans>Appointments</Trans></span>
              <i className="menu-arrow"></i>
              <i className="mdi mdi-format-list-bulleted menu-icon"></i>
            </div>
            <Collapse in={this.state.AppointmentMenuOpen}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item"> <Link className={this.isPathActive('/Appointment/basic-elements') ? 'nav-link active' : 'nav-link'} to="/Appointment/basic-elements"><Trans>Basic Elements</Trans></Link></li>
                <li className="nav-item"> <Link className={this.isPathActive('/Appointment/ManageAppointment') ? 'nav-link active' : 'nav-link'} to="/Appointment/ManageAppointment"><Trans>ManageAppointment</Trans></Link></li>
                <li className="nav-item"> <Link className={this.isPathActive('/Appointment/ViewAppointments') ? 'nav-link active' : 'nav-link'} to="/Appointment/ViewAppointments"><Trans>ViewAppointments</Trans></Link></li>
              </ul>
            </Collapse>
          </li>
          <li className={this.isPathActive('/Complaints') ? 'nav-item active' : 'nav-item'}>
            <div className={this.state.ComplaintsMenuOpen ? 'nav-link menu-expanded' : 'nav-link'} onClick={() => this.toggleMenuState('ComplaintsMenuOpen')} data-toggle="collapse">
              <span className="menu-title"><Trans>Complaints</Trans></span>
              <i className="menu-arrow"></i>
              <i className="mdi mdi-table-large menu-icon"></i>
            </div>
            <Collapse in={this.state.ComplaintsMenuOpen}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item"> <Link className={this.isPathActive('/Complaints/basic-table') ? 'nav-link active' : 'nav-link'} to="/Complaints/basic-table"><Trans>Basic Table</Trans></Link></li>
                <li className="nav-item"> <Link className={this.isPathActive('/Complaints/ManageComplaints') ? 'nav-link active' : 'nav-link'} to="/Complaints/ManageComplaints"><Trans>ManageComplaints</Trans></Link></li>
                <li className="nav-item"> <Link className={this.isPathActive('/Complaints/ViewComplaints') ? 'nav-link active' : 'nav-link'} to="/Complaints/ViewComplaints"><Trans>ViewComplaints</Trans></Link></li>
              </ul>
            </Collapse>
          </li>
          <li className={this.isPathActive('/UnblockUser') ? 'nav-item active' : 'nav-item'}>
            <div className={this.state.UnblockUserMenuOpen ? 'nav-link menu-expanded' : 'nav-link'} onClick={() => this.toggleMenuState('UnblockUserMenuOpen')} data-toggle="collapse">
              <span className="menu-title"><Trans>UnblockUser</Trans></span>
              <i className="menu-arrow"></i>
              <i className="mdi mdi-contacts menu-icon"></i>
            </div>
            <Collapse in={this.state.UnblockUserMenuOpen}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item"> <Link className={this.isPathActive('/UnblockUser/mdi') ? 'nav-link active' : 'nav-link'} to="/UnblockUser/mdi"><Trans>Material</Trans></Link></li>
                <li className="nav-item"> <Link className={this.isPathActive('/UnblockUser/UnblockUsers') ? 'nav-link active' : 'nav-link'} to="/UnblockUser/UnblockUsers"><Trans>UnblockUser</Trans></Link></li>
              </ul>
            </Collapse>
          </li>
          {/* <li className={this.isPathActive('/charts') ? 'nav-item active' : 'nav-item'}>
            <div className={this.state.chartsMenuOpen ? 'nav-link menu-expanded' : 'nav-link'} onClick={() => this.toggleMenuState('chartsMenuOpen')} data-toggle="collapse">
              <span className="menu-title"><Trans>Charts</Trans></span>
              <i className="menu-arrow"></i>
              <i className="mdi mdi-chart-bar menu-icon"></i>
            </div>
            <Collapse in={this.state.chartsMenuOpen}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item"> <Link className={this.isPathActive('/charts/chart-js') ? 'nav-link active' : 'nav-link'} to="/charts/chart-js"><Trans>Chart Js</Trans></Link></li>
              </ul>
            </Collapse>
          </li> */}
          <li className={this.isPathActive('/user-pages') ? 'nav-item active' : 'nav-item'}>
            <div className={this.state.userPagesMenuOpen ? 'nav-link menu-expanded' : 'nav-link'} onClick={() => this.toggleMenuState('userPagesMenuOpen')} data-toggle="collapse">
              <span className="menu-title"><Trans>User Pages</Trans></span>
              <i className="menu-arrow"></i>
              <i className="mdi mdi-lock menu-icon"></i>
            </div>
            <Collapse in={this.state.userPagesMenuOpen}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item"> <Link className={this.isPathActive('/user-pages/login-1') ? 'nav-link active' : 'nav-link'} to="/user-pages/login-1"><Trans>Login</Trans></Link></li>
                <li className="nav-item"> <Link className={this.isPathActive('/user-pages/register-1') ? 'nav-link active' : 'nav-link'} to="/user-pages/register-1"><Trans>Register</Trans></Link></li>
                <li className="nav-item"> <Link className={this.isPathActive('/user-pages/lockscreen') ? 'nav-link active' : 'nav-link'} to="/user-pages/lockscreen"><Trans>Lockscreen</Trans></Link></li>
              </ul>
            </Collapse>
          </li>
          {/* <li className={this.isPathActive('/error-pages') ? 'nav-item active' : 'nav-item'}>
            <div className={this.state.errorPagesMenuOpen ? 'nav-link menu-expanded' : 'nav-link'} onClick={() => this.toggleMenuState('errorPagesMenuOpen')} data-toggle="collapse">
              <span className="menu-title"><Trans>Error Pages</Trans></span>
              <i className="menu-arrow"></i>
              <i className="mdi mdi-security menu-icon"></i>
            </div>
            <Collapse in={this.state.errorPagesMenuOpen}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item"> <Link className={this.isPathActive('/error-pages/error-404') ? 'nav-link active' : 'nav-link'} to="/error-pages/error-404">404</Link></li>
                <li className="nav-item"> <Link className={this.isPathActive('/error-pages/error-500') ? 'nav-link active' : 'nav-link'} to="/error-pages/error-500">500</Link></li>
              </ul>
            </Collapse>
          </li> */}
          {/* <li className={this.isPathActive('/general-pages') ? 'nav-item active' : 'nav-item'}>
            <div className={this.state.generalPagesMenuOpen ? 'nav-link menu-expanded' : 'nav-link'} onClick={() => this.toggleMenuState('generalPagesMenuOpen')} data-toggle="collapse">
              <span className="menu-title"><Trans>General Pages</Trans></span>
              <i className="menu-arrow"></i>
              <i className="mdi mdi-medical-bag menu-icon"></i>
            </div>
            <Collapse in={this.state.generalPagesMenuOpen}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item"> <Link className={this.isPathActive('/general-pages/blank-page') ? 'nav-link active' : 'nav-link'} to="/general-pages/blank-page"><Trans>Blank Page</Trans></Link></li>
              </ul>
            </Collapse>
          </li> */}
          
        </ul>
      </nav>
    );
  }

  isPathActive(path) {
    return this.props.location.pathname.startsWith(path);
  }

  componentDidMount() {
    this.onRouteChanged();
    // add class 'hover-open' to sidebar navitem while hover in sidebar-icon-only menu
    const body = document.querySelector('body');
    document.querySelectorAll('.sidebar .nav-item').forEach((el) => {

      el.addEventListener('mouseover', function () {
        if (body.classList.contains('sidebar-icon-only')) {
          el.classList.add('hover-open');
        }
      });
      el.addEventListener('mouseout', function () {
        if (body.classList.contains('sidebar-icon-only')) {
          el.classList.remove('hover-open');
        }
      });
    });
  }

}

export default withRouter(SidebarCopy);