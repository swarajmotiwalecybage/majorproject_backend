import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';
import { Collapse } from 'react-bootstrap';
import { Trans } from 'react-i18next';
import { login, usersRoleId } from '../utils/AllAPIS';

class Sidebar extends Component {

  state = {};

  toggleMenuState(menuState) {
    if (this.state[menuState]) {
      this.setState({ [menuState]: false });
    } else if (Object.keys(this.state).length === 0) {
      this.setState({ [menuState]: true });
    } else {
      Object.keys(this.state).forEach(i => {
        this.setState({ [i]: false });
      });
      this.setState({ [menuState]: true });
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.location !== prevProps.location) {
      this.onRouteChanged();
    }
  }

  onRouteChanged() {
    document.querySelector('#sidebar').classList.remove('active');
    Object.keys(this.state).forEach(i => {
      this.setState({ [i]: false });
    });

    const dropdownPaths = [
      { path: '/apps', state: 'appsMenuOpen' },
      { path: '/ShowUsers', state: 'ShowUsersMenuOpen' },
      { path: '/advanced-ui', state: 'advancedUiMenuOpen' },
      { path: '/Appointment', state: 'AppointmentMenuOpen' },
      { path: '/Complaints', state: 'ComplaintsMenuOpen' },
      { path: '/maps', state: 'mapsMenuOpen' },
      { path: '/UnblockUser', state: 'UnblockUserMenuOpen' },
      { path: '/charts', state: 'chartsMenuOpen' },
      { path: '/user-pages', state: 'userPagesMenuOpen' },
      // { path: '/error-pages', state: 'errorPagesMenuOpen' },
      // { path: '/general-pages', state: 'generalPagesMenuOpen' },
      { path: '/ecommerce', state: 'ecommercePagesMenuOpen' },
    ];

    dropdownPaths.forEach((obj => {
      if (this.isPathActive(obj.path)) {
        this.setState({ [obj.state]: true })
      }
    }));

  }

  render() {
    return (
      <nav className="sidebar sidebar-offcanvas" id="sidebar">
        <ul className="nav">
          <li className="nav-item nav-profile">

          </li>
          <li className={this.isPathActive('/dashboard') ? 'nav-item active' : 'nav-item'}>
            <Link className="nav-link" to="/dashboard">
              <span className="menu-title"><Trans>Dashboard</Trans></span>
              <i className="mdi mdi-home menu-icon"></i>
            </Link>
          </li>
          <li className={this.isPathActive('/ShowUsers') ? 'nav-item active' : 'nav-item'}>
            <div className={this.state.ShowUsersMenuOpen ? 'nav-link menu-expanded' : 'nav-link'} onClick={() => this.toggleMenuState('ShowUsersMenuOpen')} data-toggle="collapse">
              <span className="menu-title"><Trans>Show Users</Trans></span>
              <i className="menu-arrow"></i>
              <i className="mdi mdi-crosshairs-gps menu-icon"></i>
            </div>
            <Collapse in={this.state.ShowUsersMenuOpen}>
              <ul className="nav flex-column sub-menu">
                <li className="nav-item"> <Link className={this.isPathActive('/ShowUsers/dropdowns') ? 'nav-link active' : 'nav-link'} to="/ShowUsers/dropdowns"><Trans>Dropdowns</Trans></Link></li>
                {Number(sessionStorage.getItem(usersRoleId)) === 1 &&
                  <li className="nav-item"> <Link className={this.isPathActive('/ShowUsers/PatientList') ? 'nav-link active' : 'nav-link'} to="/ShowUsers/PatientList">
                    <Trans>View Patients</Trans>
                  </Link>
                  </li> }
                <li className="nav-item">
                  <Link className={this.isPathActive('/ShowUsers/DoctorsList') ? 'nav-link active' : 'nav-link'} to="/ShowUsers/DoctorsList">
                    <Trans>View Doctors</Trans>
                  </Link>
                </li>
                {Number(sessionStorage.getItem(usersRoleId)) === 1 &&
                  <li className="nav-item">
                    <Link className={this.isPathActive('/ShowUsers/AllUsersList') ? 'nav-link active' : 'nav-link'} to="/ShowUsers/AllUsersList">
                      <Trans>View All Users</Trans>
                    </Link>
                  </li>}
              </ul>
            </Collapse>
          </li>
          {sessionStorage.getItem(login) === "true" ?
            <li className={this.isPathActive('/Appointment') ? 'nav-item active' : 'nav-item'}>
              <div className={this.state.AppointmentMenuOpen ? 'nav-link menu-expanded' : 'nav-link'} onClick={() => this.toggleMenuState('AppointmentMenuOpen')} data-toggle="collapse">
                <span className="menu-title"><Trans>Appointments</Trans></span>
                <i className="menu-arrow"></i>
                <i className="mdi mdi-format-list-bulleted menu-icon"></i>
              </div>
              <Collapse in={this.state.AppointmentMenuOpen}>
                <ul className="nav flex-column sub-menu">
                  {Number(sessionStorage.getItem(usersRoleId)) === 1 ?
                    <li className="nav-item"> <Link className={this.isPathActive('/Appointment/ManageAppointment') ? 'nav-link active' : 'nav-link'} to="/Appointment/ManageAppointment">
                      <Trans>Manage Appointment</Trans>
                    </Link>
                    </li> : ""}
                  {(Number(sessionStorage.getItem(usersRoleId)) === 2 || Number(sessionStorage.getItem(usersRoleId)) === 3) ?
                    <li className="nav-item">
                      <Link className={this.isPathActive('/Appointment/ViewAppointments') ? 'nav-link active' : 'nav-link'} to="/Appointment/ViewAppointments">
                        <Trans>View Appointments</Trans>
                      </Link>
                    </li> : ""}
                </ul>
              </Collapse>
            </li> : ""}
          {sessionStorage.getItem(login) === "true" ?
            <li className={this.isPathActive('/Complaints') ? 'nav-item active' : 'nav-item'}>
              <div className={this.state.ComplaintsMenuOpen ? 'nav-link menu-expanded' : 'nav-link'} onClick={() => this.toggleMenuState('ComplaintsMenuOpen')} data-toggle="collapse">
                <span className="menu-title"><Trans>Complaints</Trans></span>
                <i className="menu-arrow"></i>
                <i className="mdi mdi-table-large menu-icon"></i>
              </div>
              <Collapse in={this.state.ComplaintsMenuOpen}>
                <ul className="nav flex-column sub-menu">
                  {Number(sessionStorage.getItem(usersRoleId)) === 1 ?
                    <li className="nav-item">
                      <Link className={this.isPathActive('/Complaints/ManageComplaints') ? 'nav-link active' : 'nav-link'} to="/Complaints/ManageComplaints">
                        <Trans>Manage Complaints</Trans>
                      </Link>
                    </li> : ""}
                  {Number(sessionStorage.getItem(usersRoleId)) === 2 ?
                    <li className="nav-item">
                      <Link className={this.isPathActive('/Complaints/ViewComplaints') ? 'nav-link active' : 'nav-link'} to="/Complaints/ViewComplaints">
                        <Trans>View Complaints</Trans>
                      </Link>
                    </li> : ""}
                </ul>
              </Collapse>
            </li> : ""}
          {Number(sessionStorage.getItem(usersRoleId)) === 1 ?
            <li className={this.isPathActive('/UnblockUser') ? 'nav-item active' : 'nav-item'}>
              <div className={this.state.UnblockUserMenuOpen ? 'nav-link menu-expanded' : 'nav-link'} onClick={() => this.toggleMenuState('UnblockUserMenuOpen')} data-toggle="collapse">
                <span className="menu-title"><Trans>Unblock User</Trans></span>
                <i className="menu-arrow"></i>
                <i className="mdi mdi-contacts menu-icon"></i>
              </div>
              <Collapse in={this.state.UnblockUserMenuOpen}>
                <ul className="nav flex-column sub-menu">
                  <li className="nav-item"> <Link className={this.isPathActive('/UnblockUser/UnblockUsers') ? 'nav-link active' : 'nav-link'} to="/UnblockUser/UnblockUsers"><Trans>User</Trans></Link></li>
                </ul>
              </Collapse>
            </li> : ""}
          {sessionStorage.getItem(login) === "true" ?
            <li className={this.isPathActive('/user-pages') ? 'nav-item active' : 'nav-item'}>
              <div className={this.state.userPagesMenuOpen ? 'nav-link menu-expanded' : 'nav-link'} onClick={() => this.toggleMenuState('userPagesMenuOpen')} data-toggle="collapse">
                <span className="menu-title"><Trans>Profile</Trans></span>
                <i className="menu-arrow"></i>
                <i className="mdi mdi-lock menu-icon"></i>
              </div>
              <Collapse in={this.state.userPagesMenuOpen}>
                <ul className="nav flex-column sub-menu">
                  <li className="nav-item"> <Link className={this.isPathActive('/user-pages/register-1') ? 'nav-link active' : 'nav-link'} to="/user-pages/register-1"><Trans>View Your Profile</Trans></Link></li>
                </ul>
              </Collapse>
            </li> : ""}

        </ul>
      </nav>
    );
  }

  isPathActive(path) {
    return this.props.location.pathname.startsWith(path);
  }

  componentDidMount() {
    this.onRouteChanged();
    // add class 'hover-open' to sidebar navitem while hover in sidebar-icon-only menu
    const body = document.querySelector('body');
    document.querySelectorAll('.sidebar .nav-item').forEach((el) => {

      el.addEventListener('mouseover', function () {
        if (body.classList.contains('sidebar-icon-only')) {
          el.classList.add('hover-open');
        }
      });
      el.addEventListener('mouseout', function () {
        if (body.classList.contains('sidebar-icon-only')) {
          el.classList.remove('hover-open');
        }
      });
    });
  }

}

export default withRouter(Sidebar);