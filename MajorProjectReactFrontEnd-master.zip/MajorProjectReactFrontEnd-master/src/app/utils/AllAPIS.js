

export const baseURL = "http://localhost:8085"


export const registerPatientURL = baseURL + "/users/add-user"
export const sendLoginOTP = baseURL + "/users/users-login"
export const verifyLoginOTP = baseURL + "/users/verify-otp"
export const getAllUsers = baseURL + "/users/get-all-users"
export const getAllUsersByAccountStatus = baseURL + "/users/get-all-users-by-account-status"
export const getAllPatients = baseURL + "/users/get-all-patients"
export const getAllDoctors = baseURL + "/users/get-all-doctors"
export const getAllDoctorsBySpecialization = baseURL + "/users/doctors-with-specialization"

export const addAppointmentURL = baseURL + "/appointments/add-appointment"
export const getAllAppointmentsForAdmin = baseURL + "/appointments/admin/get-all"
export const getAllAppointmentsForPatient = baseURL + "/appointments/patient/get-all"
export const getAllAppointmentsForDoctor = baseURL + "/appointments/doctor/get-all"
export const getAppointmentById = baseURL + "/appointments/get-by-id"
export const addPrescription = baseURL + "/appointments/add-prescription"
export const updateAppointment = baseURL + "/appointments/update-appointment"



export const getAllSpecialization = baseURL + "/specialization/get-all"


export const login = "isUserLoggedIn"
export const usersId = "usersId"
export const usersRoleId = "usersRoleId"
export const usersFirstname = "usersFirstname"
export const appointmentStatus = [
    "APPROVE", "REJECTED", "CANCELED"
]
export const allAppointmentStatus = {
    PENDING: "PENDING",
    COMPLETED: "COMPLETED",
    APPROVE: "APPROVE",
    REJECTED: "REJECTED",
    CANCELED: "CANCELED"

}



export const usersAccountStatus = [
    "ACTIVE", "INACTIVE", "BLOCKED", "BLOCKED_BY_ADMIN", "DELETED"
]



// @GetMapping("/get-all-users")
// @GetMapping("/get-all-patients")
// @GetMapping("/get-all-doctors")

// @GetMapping("/get-user-by-id/{usersId}")

// @GetMapping("/users-login/{email}")

// @GetMapping("/verify-otp/{email}/{otp}")

// @GetMapping("/activate-account/{usersId}")

// @PostMapping("/add-doctor")

// @PostMapping("/add-user")

// @PostMapping("/update-user/{usersId}")

// @GetMapping("/delete-user/{usersId}")

// @GetMapping("/doctors-with-specialization/{specializationId}")

// @GetMapping("/unblock-account/{usersId}")